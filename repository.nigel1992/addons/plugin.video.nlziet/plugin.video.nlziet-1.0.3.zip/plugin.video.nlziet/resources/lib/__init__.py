# resources.lib package initializer
