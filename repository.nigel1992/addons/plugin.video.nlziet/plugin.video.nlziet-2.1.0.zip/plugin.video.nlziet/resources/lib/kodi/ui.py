import os
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin


def build_url(base_url, query):
    return base_url + '?' + urllib.parse.urlencode(query)


def make_color_tag(color_raw, text):
    """Return a Kodi COLOR tag using the raw value provided by the caller."""
    if not color_raw:
        return f"[COLOR FFA500]{text}[/COLOR]"
    return f"[COLOR {color_raw}]{text}[/COLOR]"


def pick_menu_icon(addon_path, name):
    """Prefer media/menu/{name}.png, then menu_{name}.png/.svg, then the addon icon."""
    candidates = [
        os.path.join(addon_path, 'resources', 'media', 'menu', f'{name}.png'),
        os.path.join(addon_path, 'resources', 'media', f'menu_{name}.png'),
        os.path.join(addon_path, 'resources', 'media', f'menu_{name}.svg'),
        os.path.join(addon_path, 'icon.png'),
    ]
    for c in candidates:
        try:
            if c and os.path.exists(c):
                return c
        except Exception:
            continue
    return None


def pick_menu_png(addon_path, name):
    """Explicit PNG-first picker (media/menu/{name}.png, a new path so Kodi's
    texture cache never shows the older icons that used the same file names)."""
    for png in (os.path.join(addon_path, 'resources', 'media', 'menu', f'{name}.png'),
                os.path.join(addon_path, 'resources', 'media', f'menu_{name}.png')):
        try:
            if png and os.path.exists(png):
                return png
        except Exception:
            pass
    return pick_menu_icon(addon_path, name)


def add_directory_item(addon, handle, build_url_func, api_instance_getter,
                       title, query, is_folder=True, is_playable=None, thumb=None,
                       info=None,
                       content=None, playback_state=None, is_live=False,
                       group=None,
                       add_to_library_label='Add to library',
                       remove_from_library_label='Remove from library',
                       library_check=None,
                       extra_art=None,
                       mylist_add_label='Add to My List',
                       mylist_remove_label='Remove from My List',
                       watch_later_add_label='Add to Watch Later',
                       watch_later_remove_label='Remove from Watch Later',
                       my_series_add_label='Add to My Series',
                       my_series_remove_label='Remove from My Series',
                       add_series_watch_later_label=None,
                        extra_context_items=None):
    url = build_url_func(query)
    li = xbmcgui.ListItem(label=title, offscreen=True)

    # Set background image on each item for skin display
    try:
        addon_path = xbmc.translatePath(addon.getAddonInfo('path')) or addon.getAddonInfo('path') or ''
        background_path = os.path.join(addon_path, 'resources', 'media', 'background.jpg')
        if os.path.exists(background_path):
            li.setArt({'fanart': background_path})
    except Exception:
        pass

    if thumb or content:
        # Use smart artwork assignment to respect aspect ratios
        # Prevents face-cutting and image stretching by assigning portraits to poster, landscapes to fanart
        set_smart_artwork(li, content, thumb=thumb)
    if extra_art:
        try:
            li.setArt(dict(extra_art))
        except Exception:
            pass

    item_info = dict(info or {})

    if item_info:
        if is_live:
            # For live TV, set video info to display EPG, but don't track resume points
            # or watched status (live channels should never show a checkmark).
            info_copy = item_info.copy()
            info_copy.pop('resume', None)  # Remove any resume position
            info_copy['playcount'] = 0     # Prevent watched/checkmark indicator
            li.setInfo('video', info_copy)
        else:
            # For on-demand content, set full video info (allows resume functionality)
            li.setInfo('video', item_info)
            try:
                short = item_info.get('plotoutline') or item_info.get('plot') or ''
                if short:
                    li.setLabel2(short)
            except Exception:
                pass
    # Non-folder items default to playable so Enter/Select triggers playback.
    # Callers can opt out (is_playable=False) to create an "action" command item
    # (e.g. Login/Logout) that runs the plugin without being treated as playable.
    if is_playable is None:
        is_playable = not is_folder
    if is_playable:
        li.setProperty('IsPlayable', 'true')

    resume = (playback_state or {}).get('resume') if playback_state else None
    if resume:
        li.setProperty('ResumeTime', str(resume['position']))
        li.setProperty('TotalTime', str(resume['total']))

    # For live TV, prevent Kodi from showing a resume prompt. A zero-length
    # resume point makes Kodi skip the bookmark database lookup entirely.
    if is_live:
        try:
            li.getVideoInfoTag().setResumePoint(0.0, 3600.0)
        except Exception:
            li.setProperty('ResumeTime', '0')
            li.setProperty('TotalTime', '3600')
        li.setProperty('IsLive', 'true')  # Mark as live for skin awareness
    # Add context-menu entries for My List / Watch Later / library when we can
    # determine a content id. All entries are collected and applied in a single
    # call: Kodi's addContextMenuItems replaces the list on each call, so
    # calling it repeatedly would discard earlier items.
    context_items = []
    try:
        content_id = None
        content_type = None
        # Prefer explicit content dict when provided
        if content and isinstance(content, dict):
            content_id = content.get('id') or content.get('contentId') or content.get('content_id') or content.get('seriesId') or content.get('movieId') or content.get('assetId')
            content_type = content.get('type') or content.get('contentType') or None
        # Fallback: inspect the query params for common id keys
        if not content_id and isinstance(query, dict):
            for k in ('id', 'series_id', 'seriesId', 'movieId', 'contentId', 'content_id'):
                if k in query and query.get(k):
                    content_id = query.get(k)
                    break
        # My List and Watch Later accept any content we can identify (by id).
        allow_mylist = bool(content_id)
        # Treat an explicit series_detail entry as a series when no type was supplied.
        if (not content_type and isinstance(query, dict)
                and (query.get('mode') or '').lower() == 'series_detail'):
            content_type = 'series'
        # Infer the canonical category when the caller did not pass one. This
        # keeps stored items grouped correctly even when only the type is known
        # (TV Shows and Documentaries cannot be told apart from Series here, so
        # their browse screens pass an explicit group).
        if not group and content_type:
            ctype = str(content_type).lower()
            if 'channel' in ctype or 'live' in ctype:
                group = 'channels'
            elif 'movie' in ctype or 'film' in ctype:
                group = 'movies'
            elif 'series' in ctype or 'tvshow' in ctype:
                group = 'series'

        context_items = []
        if content_id:
            try:
                # Use cached API instance instead of creating new ones for every item
                api_tmp = api_instance_getter()
            except Exception:
                api_tmp = None

            def _check(method_name):
                try:
                    return bool(api_tmp and getattr(api_tmp, method_name)(content_id))
                except Exception:
                    return False

            # My List accepts any content; the Watch Later / My Series choice
            # depends on the content type so each item shows the option that
            # actually works for it (series follow, episodes/movies queue).
            ctype_l = str(content_type or '').lower()
            grp_l = str(group or '').lower()
            is_series_item = 'series' in ctype_l or 'tvshow' in ctype_l or grp_l == 'series'
            is_channel_item = 'channel' in ctype_l or 'live' in ctype_l or grp_l == 'channels'

            if allow_mylist and is_series_item:
                my_series_label = my_series_remove_label if _check('is_in_my_series') else my_series_add_label
                my_series_query = {'mode': 'toggle_my_series', 'id': str(content_id), 'title': title}
                if content_type:
                    my_series_query['type'] = content_type
                if group:
                    my_series_query['group'] = group
                if thumb:
                    my_series_query['thumb'] = thumb
                try:
                    context_items.append((my_series_label, f"RunPlugin({build_url_func(my_series_query)})"))
                except Exception:
                    pass
            elif allow_mylist and not is_channel_item:
                # Episodes, movies and unknown playables queue in Watch Later.
                watch_later_label = watch_later_remove_label if _check('is_in_watch_later') else watch_later_add_label

                watch_query = {'mode': 'toggle_watch_later', 'id': str(content_id), 'title': title}
                if content_type:
                    watch_query['type'] = content_type
                if group:
                    watch_query['group'] = group
                if thumb:
                    watch_query['thumb'] = thumb
                try:
                    context_items.append((watch_later_label, f"RunPlugin({build_url_func(watch_query)})"))
                except Exception:
                    pass

            if allow_mylist and not is_channel_item and add_series_watch_later_label and (is_series_item or 'episode' in ctype_l or grp_l == 'episodes'):
                series_id = content_id if is_series_item else (content.get('seriesId') if isinstance(content, dict) else None)
                series_title = (content.get('title') if isinstance(content, dict) else None) or title
                series_query = {'mode': 'add_series_watch_later', 'series_id': str(series_id or ''), 'title': series_title}
                try:
                    context_items.append((add_series_watch_later_label, f"RunPlugin({build_url_func(series_query)})"))
                except Exception:
                    pass

        # Kodi library: series (folders) and movies (playable items).
        library_kind = None
        if content_id and isinstance(query, dict):
            ctype_lib = str(content_type or '').lower()
            if query.get('mode') == 'series_detail':
                library_kind = 'series'
            elif (query.get('mode') == 'play' and not is_live
                  and (str(group or '').lower() == 'movies' or 'movie' in ctype_lib or 'film' in ctype_lib)):
                library_kind = 'movie'
        if library_kind:
            try:
                in_library = bool(library_check and library_check(library_kind, content_id))
            except Exception:
                in_library = False
            try:
                cm_query = {'mode': 'library_toggle', 'kind': library_kind, 'id': str(content_id)}
                lib_title = (content.get('title') if isinstance(content, dict) else None) or title
                if lib_title:
                    cm_query['title'] = lib_title
                if isinstance(content, dict):
                    lib_poster = pick_portrait_thumb(content)
                    lib_fanart = pick_landscape_thumb(content)
                    if lib_poster:
                        cm_query['poster'] = lib_poster
                    if lib_fanart:
                        cm_query['fanart'] = lib_fanart
                elif thumb:
                    cm_query['poster'] = thumb
                label = remove_from_library_label if in_library else add_to_library_label
                context_items.append((label, f"RunPlugin({build_url_func(cm_query)})"))
            except Exception:
                pass

    except Exception:
        pass
    if extra_context_items:
        context_items = list(context_items) + list(extra_context_items)
    if context_items:
        try:
            li.addContextMenuItems(context_items)
        except Exception:
            pass
    xbmcplugin.addDirectoryItem(handle, url, li, isFolder=is_folder)


def optimize_image_url(url):
    """Optimize image URLs to request higher-resolution versions for fanart.

    The NLZiet image service returns low-res images (1280x720) by default.
    Request a larger resolution to avoid pixelation when displayed as fanart.
    """
    if not url or not isinstance(url, str):
        return url

    # Never touch signed/expiring URLs: stripping their query string would
    # remove tokens/signatures and break the image.
    if '?' in url:
        try:
            from urllib.parse import urlparse, parse_qsl, urlencode
            parsed = urlparse(url)
            params = dict(parse_qsl(parsed.query, keep_blank_values=True))
            auth_keys = {'token', 'sig', 'signature', 'key', 'auth', 'expires',
                         'expiry', 'exp', 'hash', 'hmac'}
            if auth_keys & {k.lower() for k in params}:
                return url
            # Drop only known width/crop params, keep the rest.
            for k in ('width', 'w', 'crop', 'resize', 'size', 'quality', 'q'):
                params.pop(k, None)
            params['width'] = '3840'
            new_query = urlencode(params)
            return parsed._replace(query=new_query).geturl()
        except Exception:
            return url

    # Plain URL: append the width hint.
    return url + '?width=3840'


def _first_content_url(src):
    """Return the best url-like value on ``src``, brand logos taken last.

    Key names that indicate a broadcaster/channel logo (``logoUrl`` and
    friends) are only used when no other image exists, so a station logo
    never outranks real content artwork like posters or stills.
    """
    candidates = []
    logos = []
    for key, value in src.items():
        if not isinstance(value, str):
            continue
        if not (value.startswith('http://') or value.startswith('https://') or value.startswith('file://')):
            continue
        if isinstance(key, str) and 'logo' in key.lower():
            logos.append(value)
        else:
            candidates.append(value)
    for value in candidates or logos:
        return optimize_image_url(value)
    return None


def pick_landscape_thumb(src):
    """Return the best landscape-oriented thumbnail or path for an item.

    Accepts either a string URL/path or a dict-like content item. Prefers
    explicit landscape keys, then common wide/hero/poster keys, and finally
    falls back to any url-like string found on the object.
    """
    if not src:
        return None
    if isinstance(src, str):
        return optimize_image_url(src)
    try:
        # Prefer explicit landscape / wide keys first
        for k in ('landscapeUrl', 'landscape', 'thumbnailLandscape', 'thumbnail_landscape', 'posterLandscape', 'poster_landscape', 'heroImage', 'heroImageUrl', 'widePosterUrl'):
            v = src.get(k)
            if isinstance(v, str) and v:
                return optimize_image_url(v)

        # Common poster/thumbnail fields (posterUrl may be portrait but is a useful fallback)
        for k in ('posterUrl', 'poster', 'thumbnail', 'thumb'):
            v = src.get(k)
            if isinstance(v, str) and v:
                return optimize_image_url(v)

        # Check nested image dicts for landscape keys
        for img_key in ('image', 'images'):
            img = src.get(img_key)
            if isinstance(img, dict):
                for k in ('landscapeUrl', 'landscape', 'landscape_url', 'wide', 'wideUrl', 'large', 'largeUrl', 'posterUrl', 'thumbnail', 'thumb'):
                    v = img.get(k)
                    if isinstance(v, str) and v:
                        return optimize_image_url(v)
                for kk, vv in img.items():
                    if isinstance(kk, str) and 'landscape' in kk.lower() and isinstance(vv, str) and vv:
                        return vv

        # Any key name containing 'landscape' on the top-level
        for kk, vv in src.items():
            if isinstance(kk, str) and 'landscape' in kk.lower() and isinstance(vv, str) and vv:
                return optimize_image_url(vv)

        # As a final fallback, return any url-like string value; broadcaster
        # logos only when no other image is available
        generic = _first_content_url(src)
        if generic:
            return generic
    except Exception:
        pass
    return None


def pick_portrait_thumb(src):
    """Return the best portrait-oriented thumbnail or path for an item.

    Portrait images are typically 2:3 aspect ratio (posters/covers).
    Prefers explicit portrait keys, then falls back to landscape or generic thumbnails.
    """
    if not src:
        return None
    if isinstance(src, str):
        return optimize_image_url(src)
    try:
        # Prefer explicit portrait / tall keys first
        for k in ('portraitUrl', 'portrait', 'posterUrl', 'poster', 'thumbnailPortrait', 'thumbnail_portrait', 'coverUrl', 'cover'):
            v = src.get(k)
            if isinstance(v, str) and v:
                return optimize_image_url(v)
        # Check nested image dicts for portrait keys
        for img_key in ('image', 'images'):
            img = src.get(img_key)
            if isinstance(img, dict):
                for k in ('portraitUrl', 'portrait', 'portrait_url', 'posterUrl', 'poster', 'coverUrl', 'cover', 'thumbnail', 'thumb'):
                    v = img.get(k)
                    if isinstance(v, str) and v:
                        return optimize_image_url(v)
        # Fallback to any image URL (broadcaster logos only as a last resort)
        generic = _first_content_url(src)
        if generic:
            return generic
    except Exception:
        pass
    return None


def set_smart_artwork(li, src, thumb=None):
    """Set artwork on a ListItem with proper aspect ratio handling.

    Assigns different images to different art keys based on their aspect ratios:
    - fanart (16:9 landscape) - prefers landscape images
    - poster (2:3 portrait) - prefers portrait images
    - thumb/icon (1:1 square) - uses best single image with aspect ratio preserved
    """
    if not thumb and not src:
        return

    # Extract different image types from content object
    landscape_img = None
    portrait_img = None

    if src and isinstance(src, dict):
        landscape_img = pick_landscape_thumb(src)
        portrait_img = pick_portrait_thumb(src)

    # Fallback: use provided thumb for both if we don't have separate images
    if not landscape_img and not portrait_img:
        landscape_img = thumb
        portrait_img = thumb
    elif not landscape_img:
        landscape_img = portrait_img
    elif not portrait_img:
        portrait_img = landscape_img

    # Build artwork dict with proper aspect ratio handling
    art = {}

    # Landscape images work best for fanart (16:9 aspect ratio)
    if landscape_img:
        art['fanart'] = landscape_img
        art['landscape'] = landscape_img

    # Portrait images for poster art (2:3 aspect ratio)
    if portrait_img:
        art['poster'] = portrait_img

    # Use landscape for thumb/icon with aspect ratio preservation
    # Kodi will letterbox/pillarbox to fit rather than stretch
    if landscape_img:
        art['thumb'] = landscape_img
        art['icon'] = landscape_img
    elif portrait_img:
        art['thumb'] = portrait_img
        art['icon'] = portrait_img

    # Apply artwork with fallback for older Kodi versions
    if art:
        try:
            li.setArt(art)
        except Exception:
            # Fallback: try simple thumb/icon only
            try:
                if landscape_img:
                    li.setArt({'thumb': landscape_img, 'icon': landscape_img})
            except Exception:
                pass
