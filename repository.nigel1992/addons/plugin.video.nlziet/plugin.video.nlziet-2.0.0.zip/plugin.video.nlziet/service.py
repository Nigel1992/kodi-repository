import os
import time

import xbmc
import xbmcaddon

from resources.lib import library as library_mod
from resources.lib import library_art
from resources.lib import logo_cache as logo_cache_mod
from resources.lib import metadata as metadata_mod
from resources.lib import watch_sync
from resources.lib import diagnostics as diagnostics_mod
from resources.lib import playback_extras
from resources.lib import trakt_status
from resources.lib import reminders as reminders_mod
from resources.lib import resume_store

ADDON = xbmcaddon.Addon()


ADDON_ID = 'plugin.video.nlziet'


def _maybe_play_next(content_id):
    """Binge: start the next episode by ourselves, unless the user pressed Stop
    after this one. Only in the 'auto' next-episode mode; the Up Next and
    'ask' modes handle the next episode at playback time instead.

    The setting is read from a fresh add-on instance: the long-running service
    holds a cached ADDON object that can keep returning the value it read at
    startup, so a change the user makes while Kodi runs would otherwise be
    missed (e.g. switching to 'ask' but the service still auto-plays)."""
    import xbmcaddon
    import xbmcgui
    mode = xbmcaddon.Addon().getSetting('next_episode') or 'upnext'
    if mode != 'auto':
        return
    if xbmcgui.Window(10000).getProperty('nlziet.stop_after') == '1':
        return
    from urllib.parse import quote
    xbmc.executebuiltin('RunPlugin(plugin://{}/?mode=play_next&id={}&background=1)'.format(
        ADDON_ID, quote(str(content_id), safe='')))


def _send_watched(content_id, watched):
    """Ask the plugin to tell NLZiet (runs in its own process)."""
    if not content_id or not _setting_on('watched_to_service', True):
        return
    if not REPEATS.fresh(str(content_id), watched):
        return
    xbmc.log('NLZiet service: watched={} for {}'.format(watched, content_id), xbmc.LOGINFO)
    from urllib.parse import quote
    xbmc.executebuiltin('RunPlugin(plugin://{}/?mode=remote_watched&id={}&watched={}&background=1)'.format(
        ADDON_ID, quote(str(content_id), safe=''), 1 if watched else 0))


def _rpc(method, params):
    import json
    answer = json.loads(xbmc.executeJSONRPC(json.dumps(
        {'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    return answer.get('result') or {}


def _read_text(path):
    import xbmcvfs
    handle = xbmcvfs.File(path)
    try:
        return handle.read()
    finally:
        handle.close()


class LibraryMonitor(xbmc.Monitor):
    """Notices library scans and watched/unwatched changes in Kodi's library."""

    def __init__(self):
        super().__init__()
        self.scan_finished = False

    def onScanFinished(self, library):
        if library == 'video':
            self.scan_finished = True

    def onNotification(self, sender, method, data):
        if method != 'VideoLibrary.OnUpdate':
            return
        change = watch_sync.library_update(data)
        if not change:
            return
        media_type, dbid, watched = change
        try:
            path = watch_sync.library_file(media_type, dbid, _rpc)
            params = watch_sync.plugin_params(watch_sync.strm_target(path, _read_text), ADDON_ID)
            if params.get('mode') == 'play' and params.get('id'):
                _send_watched(params['id'], watched)
        except Exception as exc:
            xbmc.log('NLZiet service: library watched check failed: {}'.format(exc), xbmc.LOGWARNING)


class PlaybackFollower(xbmc.Player):
    """Follows videos the add-on starts, to send "watched" at the end."""

    def __init__(self):
        super().__init__()
        self.watch = watch_sync.PlaybackWatch()

    def onAVStarted(self):
        import xbmcgui
        window = xbmcgui.Window(10000)
        prop = watch_sync.PLAYING_PROPERTY.format('nlziet')
        self.watch.start(watch_sync.parse_playing(window.getProperty(prop)))
        window.clearProperty(prop)
        window.clearProperty('nlziet.stop_after')
        self.sample()
        self._scrobble('start')
        # Preferred audio/subtitle language.
        audio = _setting('preferred_audio', 'off')
        sub = _setting('preferred_subtitle', 'off')
        if audio not in ('', 'off') or sub not in ('', 'off'):
            try:
                result = playback_extras.apply_language(_rpc, audio, sub)
                xbmc.log('NLZiet service: language {}'.format(result), xbmc.LOGINFO)
            except Exception as exc:
                xbmc.log('NLZiet service: language select failed: {}'.format(exc), xbmc.LOGWARNING)
        if _setting_on('auto_subtitle_search', False):
            self._maybe_find_subtitles()

    def sample(self):
        if not self.watch.key:
            return
        try:
            if self.isPlayingVideo():
                self.watch.sample(self.getTime(), self.getTotalTime())
        except RuntimeError:
            pass

    def _done(self, natural):
        self._scrobble('stop')
        key = self.watch.key
        position, total = self.watch.position, self.watch.total
        near_end = bool(total and total > 0 and position >= total - 20)
        if key and _setting_on('resume_playback', True):
            try:
                resume_store.save(_resume_path(), key, position, total)
            except Exception as exc:
                xbmc.log('NLZiet service: resume save failed: {}'.format(exc), xbmc.LOGWARNING)
        try:
            share = max(0.5, min(0.99, _int_setting('watched_threshold', 90) / 100.0))
        except Exception:
            share = 0.9
        watched = self.watch.finish(share)
        if watched:
            _send_watched(watched, True)
        # Start the next episode when the video ended, stopped within the final
        # seconds, or counts as watched (>= threshold). inputstream.adaptive
        # (DRM) often reports the end as "stopped" with a slightly stale
        # position, so relying on the end event alone missed it; the "watched"
        # signal is the reliable trigger (same idea as the Lucent Video add-on).
        if (natural or near_end or bool(watched)) and key:
            _maybe_play_next(key)

    def onPlayBackStopped(self):
        self._done(False)

    def onPlayBackEnded(self):
        self._done(True)

    def _maybe_find_subtitles(self):
        """Open Kodi's subtitle search when the video has no subtitles of its own."""
        try:
            if MONITOR.waitForAbort(3):
                return
            if not self.isPlayingVideo() or playback_extras.subtitles_present(_rpc):
                return
            xbmc.executebuiltin('ActivateWindow(subtitlesearch)')
        except Exception as exc:
            xbmc.log('NLZiet service: subtitle search skipped: {}'.format(exc), xbmc.LOGWARNING)

    def _scrobble(self, action):
        if not _setting_on('trakt_scrobble', False):
            return
        try:
            import json, xbmcaddon, xbmcgui
            trakt_addon = xbmcaddon.Addon('script.trakt')
        except Exception:
            return
        token = trakt_status.access_token(trakt_addon)
        client_id = trakt_status.official_client_id(trakt_addon.getAddonInfo('path') or '')
        if not token or not client_id:
            return
        raw = xbmcgui.Window(10000).getProperty('nlziet.now_meta')
        try:
            meta = json.loads(raw) if raw else {}
        except ValueError:
            meta = {}
        media = trakt_status.scrobble_media(meta.get('showtitle'), meta.get('season'),
                                            meta.get('episode'), meta.get('title'), meta.get('year'))
        if not media:
            return
        progress = 0.0
        if self.watch.total:
            progress = max(0.0, min(100.0, self.watch.position / self.watch.total * 100.0))
        try:
            trakt_status.scrobble(token, client_id, action, media, progress)
        except Exception:
            pass


MONITOR = LibraryMonitor()
REPEATS = watch_sync.Repeats()

# Give Kodi time to finish starting before the first library update.
LIBRARY_STARTUP_DELAY = 120


def _addon():
    import xbmcaddon
    return xbmcaddon.Addon()


def _setting(name, default=''):
    try:
        value = _addon().getSetting(name)
    except Exception:
        return default
    return default if value in ('', None) else value


def _setting_on(name, default=False):
    value = _setting(name, None)
    if value is None:
        return default
    return value in ('true', '1', 'yes', True)


def _int_setting(name, default=0):
    try:
        return int(_setting(name, default))
    except (ValueError, TypeError):
        return default


def _sync_now():
    """Trigger both cloud syncs through the plugin (runs in its own process)."""
    try:
        if _setting_on('watch_later_sync'):
            xbmc.executebuiltin('RunPlugin(plugin://plugin.video.nlziet/?mode=sync_watch_later&background=1)')
    except Exception as exc:
        xbmc.log('NLZiet service: watch-later sync trigger failed: {}'.format(exc), xbmc.LOGWARNING)
    try:
        if _setting_on('watch_later_sync'):
            xbmc.executebuiltin('RunPlugin(plugin://plugin.video.nlziet/?mode=sync_my_series&background=1)')
    except Exception as exc:
        xbmc.log('NLZiet service: my-series sync trigger failed: {}'.format(exc), xbmc.LOGWARNING)


def _library_update_due():
    """True when the library has items and the last update is old enough."""
    if not _setting_on('library_auto_update', True):
        return False
    try:
        profile = library_mod.translate_path(_addon().getAddonInfo('profile')) or ''
        store = library_mod.LibraryStore(os.path.join(profile, 'library.json'))
    except Exception:
        return False
    if not store.section('series') and not store.section('movie') and not _setting_on('library_lists_sync', True):
        return False
    hours = max(1, _int_setting('library_update_hours', 12))
    last = store.data.get('last_update') or 0
    return (time.time() - last) >= hours * 3600


def _reminders_path():
    return os.path.join(library_mod.translate_path(ADDON.getAddonInfo('profile')) or '', 'epg_reminders.json')


def _resume_path():
    return os.path.join(library_mod.translate_path(ADDON.getAddonInfo('profile')) or '', 'resume.json')


def _check_reminders():
    import xbmcgui

    def _text(row):
        name = row.get('title') or ''
        channel = row.get('channel_name') or ''
        if channel:
            return ADDON.getLocalizedString(33337).format(name, channel)
        return ADDON.getLocalizedString(33336).format(name)

    for row in reminders_mod.due(_reminders_path()):
        xbmcgui.Dialog().notification('NLZiet', _text(row), xbmcgui.NOTIFICATION_INFO, 9000)


def _daily_check_due():
    if not _setting_on('daily_check', True):
        return False
    path = os.path.join(library_mod.translate_path(ADDON.getAddonInfo('profile')) or '', 'daily_check.json')
    try:
        last = os.path.getmtime(path)
    except OSError:
        last = 0
    return diagnostics_mod.daily_due(last, time.time())


def repair_dateadded_once():
    """One-off: give existing library episodes a dateadded based on their air
    date, so "recently added" widgets order by when an episode aired (newest on
    top) instead of leaving older imports there. Updates Kodi's database
    directly, so it also fixes episodes that were already scanned."""
    if _setting_on('dateadded_repaired_v2', False):
        return
    marker = 'plugin.video.nlziet/library'
    try:
        result = _rpc('VideoLibrary.GetEpisodes',
                      {'properties': ['file', 'firstaired', 'dateadded']}) or {}
    except Exception:
        return
    changed = 0
    for ep in result.get('episodes') or []:
        path = str(ep.get('file') or '')
        aired = str(ep.get('firstaired') or '')[:10]
        if marker not in path or len(aired) != 10:
            continue
        desired = aired + ' 12:00:00'
        if str(ep.get('dateadded') or '') == desired:
            continue
        try:
            _rpc('VideoLibrary.SetEpisodeDetails',
                 {'episodeid': ep.get('episodeid'), 'dateadded': desired})
            changed += 1
        except Exception:
            pass
    try:
        ADDON.setSetting('dateadded_repaired_v2', 'true')
    except Exception:
        pass
    xbmc.log('NLZiet service: dateadded repaired for {} episodes'.format(changed), xbmc.LOGINFO)
    try:
        import xbmcgui
        xbmcgui.Dialog().notification('NLZiet', ADDON.getLocalizedString(33356).format(changed),
                                      xbmcgui.NOTIFICATION_INFO, 8000)
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass


def main():
    xbmc.log('NLZiet service: started', xbmc.LOGINFO)
    started = time.time()
    last_sync = time.time()
    last_library_trigger = 0
    last_minute = 0
    last_daily = 0
    last_notify = 0
    last_resume_sync = 0
    legacy_checked = False
    player = PlaybackFollower()
    while not MONITOR.abortRequested():
        # Short ticks so the playback position is known when a video stops.
        if MONITOR.waitForAbort(5):
            break
        player.sample()
        now = time.time()
        if now - last_minute < 60:
            continue
        last_minute = now

        if now - started >= LIBRARY_STARTUP_DELAY and not _setting_on('dateadded_repaired_v2', False):
            try:
                repair_dateadded_once()
            except Exception as exc:
                xbmc.log('NLZiet service: dateadded repair failed: {}'.format(exc), xbmc.LOGWARNING)

        # Make sure the library folders have a content type + local scraper in
        # Kodi's database, otherwise .strm/.nfo files never become entries.
        if now - started >= LIBRARY_STARTUP_DELAY and not xbmc.Player().isPlaying():
            try:
                xbmc.executebuiltin('RunPlugin(plugin://{}/?mode=fix_library_sources&background=1)'.format(ADDON_ID))
            except Exception as exc:
                xbmc.log('NLZiet service: fix library sources failed: {}'.format(exc), xbmc.LOGWARNING)

        # EPG reminders about to start (checked here, no plugin round-trip).
        try:
            _check_reminders()
        except Exception as exc:
            xbmc.log('NLZiet service: reminder check failed: {}'.format(exc), xbmc.LOGWARNING)

        if (now - started >= LIBRARY_STARTUP_DELAY + 300 and now - last_daily >= 6 * 3600
                and not xbmc.Player().isPlaying() and _daily_check_due()):
            last_daily = now
            xbmc.executebuiltin('RunPlugin(plugin://{}/?mode=daily_check&background=1)'.format(ADDON_ID))

        if (now - started >= LIBRARY_STARTUP_DELAY and now - last_notify >= 3 * 3600
                and not xbmc.Player().isPlaying() and _setting_on('notify_new_episodes', True)):
            last_notify = now
            xbmc.executebuiltin('RunPlugin(plugin://{}/?mode=notify_new&background=1)'.format(ADDON_ID))

        # Pull watch positions from NLZiet into the library (what you watched on
        # another device), shortly after startup and then once an hour.
        if (now - started >= LIBRARY_STARTUP_DELAY and now - last_resume_sync >= 3600
                and not xbmc.Player().isPlaying() and _setting_on('sync_resume_from_service', True)):
            last_resume_sync = now
            xbmc.executebuiltin('RunPlugin(plugin://{}/?mode=sync_resume&background=1)'.format(ADDON_ID))

        # A scan asked for while Kodi was busy runs as soon as it is free.
        library_art.run_pending_scan(library_mod.scan_flag_path())

        # Look up logos for titles seen in browse lists, a few at a time.
        if not xbmc.Player().isPlaying():
            try:
                folder = library_mod.translate_path(ADDON.getAddonInfo('profile')) or ''
                if os.path.isfile(os.path.join(folder, 'logo_queue.json')):
                    enricher = metadata_mod.Enricher(os.path.join(folder, 'metadata_cache.json'),
                                                     tmdb_key=_setting('tmdb_api_key', ''),
                                                     user_agent='plugin.video.nlziet')
                    logo_cache_mod.LogoCache(folder).process(enricher, limit=15,
                                                             should_stop=MONITOR.abortRequested)
                    enricher.save()
            except Exception as exc:
                xbmc.log('NLZiet service: logo lookup failed: {}'.format(exc), xbmc.LOGWARNING)

        if MONITOR.scan_finished:
            MONITOR.scan_finished = False
            library_file = os.path.join(library_mod.translate_path(ADDON.getAddonInfo('profile')) or '', 'library.json')
            if os.path.isfile(library_file):
                # New titles were just scanned: give them their posters.
                xbmc.executebuiltin('RunPlugin(plugin://plugin.video.nlziet/?mode=repair_library_art&background=1)')

        interval = _int_setting('auto_sync_interval', 0)
        if interval > 0 and now - last_sync >= interval * 60:
            last_sync = now
            _sync_now()

        # Move a library exported by 1.6.x into the add-on folder once.
        if not legacy_checked and now - started >= LIBRARY_STARTUP_DELAY and not xbmc.Player().isPlaying():
            legacy_checked = True
            if os.path.isdir(library_mod.LEGACY_TV_PATH):
                last_library_trigger = now
                xbmc.executebuiltin('RunPlugin(plugin://plugin.video.nlziet/?mode=library_update&background=1)')
                continue

        # Retry at most once an hour if an update did not record itself.
        if (now - started >= LIBRARY_STARTUP_DELAY and now - last_library_trigger >= 3600
                and not xbmc.Player().isPlaying() and _library_update_due()):
            last_library_trigger = now
            xbmc.log('NLZiet service: starting library update', xbmc.LOGINFO)
            xbmc.executebuiltin('RunPlugin(plugin://plugin.video.nlziet/?mode=library_update&background=1)')

    xbmc.log('NLZiet service: stopped', xbmc.LOGINFO)


if __name__ == '__main__':
    main()
