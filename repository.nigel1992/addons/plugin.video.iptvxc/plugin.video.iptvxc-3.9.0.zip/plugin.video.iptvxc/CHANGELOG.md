# Version 3.9.0 (2026-11-20)

### Major update
- Show a "what's new" dialog after an update.
- Added Live TV [Filtered] menu with configurable category filter.
- Live TV pause/timeshift for .ts via inputstream.ffmpegdirect.
- .ts resilience with configurable reconnect delay.
- Auto-reconnect for live streams with backoff and rapid-crash counting.
- Watched indicators and native Kodi overlays in lists.
- Trakt integration via script.trakt metadata + optional direct scrobbling.
- Update-safe cleanup of stale bytecode/cache.

# Version 3.8.12 (2026-11-19)

### ▶️ Playback / lists
- Added watched markers: episodes and other items that exist in watch history now report `PlayCount` to Kodi, so supported skins show the normal watched overlay while keeping the thumbnail.

# Version 3.8.11 (2026-11-19)

### 🧹 Update safety
- Added one-time, version-gated cleanup on update: clears stale addon cache and removes old `__pycache__` bytecode so a previously installed playback watchdog/30-second monitoring loop can no longer survive across updates.
- Prompts the user to fully restart Kodi after the cleanup for best results.

# Version 3.8.10 (2026-11-19)

### 🐛 Bug fixes (issue #9)
- Fixed Live TV, VOD, and Series categories taking hours to populate (or never loading).
- Root cause: the default network timeout was 3 seconds, but many IPTV panels need 15–45 seconds per response. Requests were cut off before the panel finished responding.
- Raised the default network timeout to 90 seconds and enforced a 90-second floor for older saved settings, so slow providers are no longer truncated.
- Added visible empty/error feedback in all category and list views, including a hint to increase the Network timeout in Settings when nothing loads.
- Verified against a real provider: Live TV categories load in ~16s, VOD in ~16s, Series in under 1s, and the full 55,000-channel "All" list loads in ~50s.

# Version 3.8.9 (2026-08-27)

### 🔎 Search and subscription readiness
- Fixed issue #7: Search no longer auto-runs the previous query when opened from the menu; it always prompts for a new scope/query.
- Fixed issue #8: validates DNS/Username/Password before searching and reports when no subscription data is loaded.
- Search now runs immediately after selecting scope.
- Search results report how many items were searched and how many matched; progress shows live "Found: N" count.
- Catch-up TV shows explicit empty/error states instead of a blank list.
- Added "Reload Subscription Data" action (clears cache) in Settings and Extras.
- Home screen shows a setup prompt when subscription details are missing.

### 📊 Telemetry
- Added anonymous usage ping (enabled by default, opt-out) with configurable counter endpoint.

# Version 3.8.8 (2026-08-26)

### 🔎 Search and navigation
- Fixed issue #2: Search now queries the actual Xtream `get_live_streams`, `get_vod_streams`, and `get_series` catalogs instead of mixing incompatible legacy panel data with a VOD category feed.
- Supports providers returning either list-shaped or dictionary-shaped JSON catalogs.
- Supports large providers that require `category_id=0` for a complete VOD catalog, then falls back to legacy panel endpoints when standard Live TV or VOD catalogs are empty.
- Search covers Live TV, catch-up, Movies/VOD, and Series, with deterministic grouping and de-duplication.
- Added a cancellable search progress window with the current section and overall percentage while catalogs are loaded, scanned, and results are built.
- The active scope/query is retained until the user returns to the main menu, so stopping playback rebuilds the same results without reopening the selector and keyboard.
- Added an explicit "No results found" entry instead of a generic add-on error.

### 📺 Live TV and EPG
- Fixed channel names becoming ambiguous or disappearing when an Enigma2 panel appends the current EPG schedule and programme title to each channel label.
- EPG-decorated Live TV listings now resolve canonical channel names from the matching Xtream category, with a safe title-prefix fallback for legacy panels.
- Programme titles and descriptions remain available as EPG/plot information without replacing the visible channel name.
- Generated PVR M3U entries now use the real channel name for `tvg-name` and the visible label, while retaining `epg_channel_id` for `tvg-id` matching.
- Removed malformed duplicate `channel-id` attributes from generated M3U entries.

### ▶️ Playback and navigation
- Fixed Last Played and Recently Watched items being registered as folders while starting playback directly, which caused Kodi `GetDirectory` errors and intermittent focus/input waits.
- Unified normal, history, and Last Played playback through Kodi's standard `setResolvedUrl()` contract.
- Explicitly marks every playback item as playable and activates fullscreen video as soon as Kodi opens the stream.
- Removed long-lived playback, EPG, and expiry worker threads from short-lived plugin invocations, preventing Kodi from waiting on abandoned add-on threads.
- Fixed recursively duplicated labels such as `Last Played just now: Last Played just now: ...`.

### 🧹 Cache and reliability
- Clear Cache now asks before deleting anything and always displays a detailed completion result.
- Retains the Kodi 21 cross-platform cache fix using `xbmcvfs.translatePath()` on Windows, Linux, LibreELEC, Android, macOS, and other supported platforms.
- Endpoint detection now continues past unsupported 404/405/5xx endpoints and tries all compatible Xtream fallbacks.
- Account-expiry checks are persisted and throttled instead of running a resident background loop.
- Favorites, history, Last Played, profiles, and related state now use atomic JSON writes to reduce corruption after an interrupted write.
- HTTPS icon hosts are probed on the correct port, malformed base64 provider metadata is handled safely, and external-IP lookup has a bounded timeout.

### 🔐 Privacy and compatibility
- Provider credentials are URL-encoded for reserved characters and redacted from add-on-generated Kodi log messages.
- Account Information masks the provider password.
- Fixed an unsafe/broken macOS sign-up launcher fallback.
- Folder entries are no longer incorrectly marked as playable.

### 📦 Packaging
- Published a clean Kodi-installable ZIP with the required top-level `plugin.video.iptvxc/` directory.
- Excludes `.git`, `.venv`, tests, caches, compiled Python files, build directories, and previous release archives.

# Version 3.8.7 (2026-08-25)

### 🐛 Bug fixes
- Fixed **Extras → Clear Cache** failing on Kodi 21 with `AttributeError: module 'xbmc' has no attribute 'translatePath'`.
- Replaced the removed `xbmc.translatePath()` call with Kodi's cross-platform `xbmcvfs.translatePath()` API, restoring cache clearing on Windows, Linux, macOS, Android, and other supported platforms.

### 📦 Packaging
- Published a Kodi-installable ZIP containing the required top-level `plugin.video.iptvxc/` directory.

# Version 3.8.6 (2026-04-01)

### 🚀 Release highlights
- Search experience completely revamped for precision and speed.
- Added optional search scope selector (Live TV/Catchup | Movies/VOD | Series | All).
- Added configurable network safeguards:
  - `net_timeout` (seconds)
  - `net_retries` (attempt count)
  - `net_backoff` (seconds between retries)
- Added resilient request strategy around `OPEN_URL()` with retry/backoff and endpoint fallback.
- Added persistent search state (query + scope + results) for reliable navigation and back/forward restore.

### 🛠️ Behavioral improvements
- Deterministic results ordering across repeated searches:
  - dedupe by normalized key (type + title)
  - forced sort priority (live → movie → vod → series → catchup)
- Eliminated stale query/scope confusion via JSON state persistence in addon_data.
- Better transient network error handling with automatic retry and graceful degradation.

### 🧹 Packaging quality
- Release package now contains only the addon folder structure (plugin.video.iptvxc/*).
- Excludes `.venv`, `.git`, `tests`, `__pycache__`, `.pyc` and previous archive artifacts.

### 🐛 Bug fixes
- Fixed inconsistent search result order and duplicate entry presentation.
- Fixed persistent query/scope reset issues on navigation back.
- Reduced failure scenario impact from temporary API endpoint failures.

# Version 3.8.5 (2026-03-31)

### ✨ Added / Improvements
- Favorites: Top-level Favorites now present as three category entries (Live TV, Movies/VOD, Series) showing counts — select a category to view its favorited items.
- Favorites: Favorites are now classified and stored with a `category` attribute (live / vod / series) to improve grouping and maintain correct ordering.
- Playback: Added per-category subtitle toggles in Settings → Playback (`subtitles_live`, `subtitles_vod`, `subtitles_series`) and the addon now enforces subtitle visibility per-category when playback starts.

### 🐛 Bug Fixes
- Fixed a minor EPG updater typo and added defensive checks around playback start to avoid subtitle/EPG races.
- Various small fixes and formatting/consistency improvements.

# Version 3.8.4 (2026-03-28)

### ✨ Added / Improvements
- Mapped `resources/media/icon_*.png` files to home menu items so the supplied icons are used for Favorites, Recently Watched, Account Info, Live TV, Movies VOD, Series, TV Guide, Catchup, Search, Settings, and Extras.
- Added `icon_LAST_PLAYED.png` and set it as the fallback for the Last Played home entry to ensure a reliable local icon.
- Set Extras to use a local `icon_EXTRAS.png` fallback to avoid blocked or unreachable remote assets.
- Updated `README.md` and `CHANGELOG.md` to document these changes.

### 🐛 Bug Fixes
- Fixed `IndentationError: unexpected indent` in `default.py` by normalizing ART PATHS and removing an unreachable nested try/except in `livecategory()`.
- Ensured the Last Played home item always uses the local icon to avoid UI issues caused by unreachable icon hosts.
- Packaging: created clean release ZIP and published release `v3.8.4` (excludes `.venv`, `__pycache__`, `.git`, and `.pyc` files).

# Version 3.8.3 (2026-03-18)

### 🐛 Bug Fixes
 - Fixed accountinfo crash when the panel API returns empty or invalid JSON. Added robust parsing, defensive checks, and string coercion for numeric fields to prevent TypeError exceptions.
 - Packaging: ensure release ZIP contains a top-level `plugin.video.iptvxc` folder and excludes any local `.venv` directory.

# Version 3.8.2 (2026-03-05)

### 🔄 Maintenance
- Version bump to 3.8.2 for latest release

# Version 3.8.1 (2026-03-05)

### 🐛 Bug Fixes
- Fixed loading spinner staying visible when playing a channel from TV Guide or Last Played

# Version 3.8.0 (2026-03-05)

### ✨ New Features
- **Custom EPG / TV Guide** — full in-addon EPG window with two-panel layout (channels + programme schedule), category browsing, search for categories and channels, progress bars on currently airing shows, and info panel
- **EPG remembers last category** — reopening the TV Guide auto-loads the previously viewed category
- **Programme click plays channel** — selecting any programme in the schedule plays that channel directly
- **Live programme info in player overlay** — pressing Info (i) during playback shows the current programme title, description, and channel name
- **Auto-updating EPG info** — background thread refreshes programme metadata every 60 seconds during playback so the info overlay always shows the current show
- **Kodistubs for development** — added pyrightconfig.json and kodistubs for linter-clean development

### 🔧 Improvements
- Simplified Last Played — plays immediately without confirmation dialog, no stale show info
- All playback paths (stream, EPG, last played/history) now set programme info and start the EPG updater
- Removed pvr.iptvsimple dependency — EPG is fully self-contained within the addon

# Version 3.7.0 (2026-03-05)

### ✨ New Features
- **Favorites** — long-press any channel, movie, or series to add/remove from Favorites; new Favorites menu on home screen for instant access to your most-watched content
- **Recently Watched History** — automatically logs the last 25 streams played (configurable); accessible from the home screen with timestamps; clear from Extras
- **EPG Now & Next** — live channel listings can now show the currently airing programme name inline (fetched in parallel with threading); enable in Settings → Features
- **Multi-Server Profiles** — save, switch between, and delete multiple IPTV server credentials from Settings → Switch Server; cache is auto-cleared on switch
- **Auto-Resume / Last Played** — the last played stream appears at the top of home as a quick-resume item; optional auto-play on first launch per Kodi session (Settings → Features)

### 🔧 Improvements
- New **Settings → Features** category for EPG Now Playing toggle, auto-resume toggle, and history size
- Context menu "Add to Favorites" / "Remove from Favorites" on all content items (Live, VOD, Series, Catchup)
- Favorites, history, last played, and profiles persist to JSON files in addon_data
- EPG data cached for 5 minutes to keep channel listings snappy after first load

# Version 3.6.0 (2026-03-03)

### 🐛 Bug Fixes
- **Fixed freeze / slowdown when pressing X to stop a stream** — the plugin monitoring loop now exits immediately once playback stops instead of spinning for the full 30-second guard window
- **Fixed intermittent loading overlay (spinning busy dialog) getting stuck** — busy dialog is now force-closed after stream resolve, and a background watchdog repeatedly closes it during teardown
- **Fixed Kodi becoming unresponsive on Stop** — removed auto-retry logic that fought the stop state; playback teardown now completes cleanly
- **Fixed slow stream start** — removed `ReconnectPlayer` double-play and sleep-loop blocking; playback now starts immediately via standard `setResolvedUrl`
- **Fixed UI freeze caused by unreachable channel icon servers** — playback `ListItem` now always uses the local addon icon; icon hosts are TCP-probed before use and replaced with a fallback if unreachable
- **Fixed 30-second curl stall on icon fetch** — added `curlclienttimeout` and `curllowtimeout` to `advancedsettings.xml` capping all thumbnail fetches at 3–5 seconds
- **Fixed intermittent loading overlay race condition** — removed `sys.exit(0)` that caused Kodi to see "script aborted" and retry stream resolution in a loop

### ✨ New Features
- **Persistent file-based content caching** for Live TV (30 min), Movies/VOD (60 min), Series (60 min), and Catch-up (15 min) — repeat navigation is near-instant
- **User-configurable cache expiry** — new **Settings → Cache** category lets users set separate expiry for Live TV, Movies, and Series (options: 5 minutes → 7 days)
- **Clear content cache** button in Settings → Cache for instant cache reset
- **Persistent icon-host reachability cache** — dead icon server results are saved to disk and survive between plugin invocations (re-tested every hour), eliminating repeated TCP probes on each list load
- **`safe_icon()` applied throughout** — both `addDir()` and `addDirMeta()` now skip unreachable icon hosts in directory listings

### 🔧 Improvements
- `setContentLookup(False)` set on playback `ListItem` to prevent Kodi probing the stream on stop
- Plugin script exits naturally after `setResolvedUrl` (clean exit instead of forced abort)
- Proper title/description metadata passed to resolve `ListItem`

# Version 3.5.2 (2026-01-28)
- Playback now automatically retries up to 5 times if the connection drops during playback or seeking (improves reliability for unstable streams)
- Version updated in addon.xml and release zip
- All previous features and fixes retained
# Changelog
#
## 3.5.1 (2026-01-27)
- Extras menu placeholders (Setup PVR Guide, Install PVR Guide, Refresh M3U, Clear Cache) are now visible but disabled in the UI. Only Speed Test is active. Disabled options will show a message if selected.
- Fixed: The version number in addon.xml now matches the release version.

## 3.5.0 (2026-01-27)
- Fixed and updated the Speed Test feature:
  - Replaced with script.speedtester logic and UI for reliability and modern look
  - Full Python 3 compatibility (threading, XML parsing, bytes/str handling)
  - Added author credit for original script.speedtester
  - Ensured no M3U/provider popups and direct launch from Extras menu
- Fixed M3U popup to no longer appear unexpectedly

## 3.4.0 (2026-01-25)
- Improved search experience:
  - Search now queries Live TV, VOD (Movies), Series and Catch-up content instead of only Live channels
  - Aggregates and displays results from all sources so no matches are missed
  - Adds colored, visible prefixes indicating the section where each result was found (Live, Movie, VOD, Series, Catch-up)
  - Playable items open directly and return to the search results after playback (no re-opening of the search dialog)
- Quality: safer parsing and fallbacks added when endpoints return non-standard payloads
- Minor: code refactor and performance adjustments for search aggregation

## 3.3.3.1 (2026-01-25)
- Updated all main icons and add-on icon with user-supplied images
- Repackaged add-on ZIP with new assets
- Version bump and release automation improvements

## 3.3.3 (2026-01-24)
- Added account expiry checks and notifications
  - On-launch check with non-intrusive notification when expiry is within threshold
  - Optional periodic background checks while addon is open (`expiry_notify_background`)
  - Configurable interval (`expiry_notify_interval_hours`) and threshold (`expiry_notify_days`)
- Moved **Test Credentials** action into **General** settings for easier access
- Fixed stray patch markers in `tools.py` that caused a startup SyntaxError
- Packaging: created clean ZIPs and improved release assets

## 3.3.2 (2026-01-23)
- Added robust "Test Credentials" workflow accessible from Settings
  - Multi-stage endpoint checker (player_api, panel_api, api.php, get.php, client_area/player_api)
  - Treats HTTP 401/403/512 as invalid credentials and reports clearly
  - Improved network and JSON error handling and helpful dialogs
- Fixed crash on some Kodi versions that lacked `xbmc.LOGNOTICE` (now handled)
- Added `get_working_endpoint()` helper and wired it to the Settings test
- Misc: improved logs and packaging

## 3.3.1 (2026-01-20)
- Removed all Trakt.tv integration (code, settings, documentation)
- Trakt will return as a feature in a future release
- Updated README and metadata to reflect Trakt status
