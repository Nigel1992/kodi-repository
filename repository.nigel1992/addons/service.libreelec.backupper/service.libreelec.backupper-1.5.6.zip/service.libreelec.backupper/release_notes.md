# LibreELEC Backupper Release Notes

## Latest Release: 1.5.6 (2026-11-26)

- Prevented backups from growing on every run by excluding the backup destination and accumulating directories (addon packages, caches, temp files, VCS metadata)
- Improved backup file collection for both single-file and directory backup items

## Previous Release: 1.5.5 (2026-11-05)

- Added optional Kodi video database backups to preserve watch status and resume positions
- Uses SQLite online backup for a consistent snapshot while Kodi runs, including committed WAL data
- Automatically detects the MyVideos database version
- Validates database integrity and preserves an installed database of the same or newer version

## Previous Release: 1.5.0 (Compared to 1.4.1.7)

- New custom GUI windows for dashboard, settings, backup browser, and dialogs (1080i/720p)
- New per-setting help text and read-only Credits handling in custom settings
- New optional post-backup summary popup setting
- New remote storage usage status details in dashboard (with fallback detection)
- Improved navigation reliability in custom settings (single-step category switching)
- Improved dashboard layout clarity by separating guidance and system status sections
- Improved Remote Settings Test Connection output with cleaner, structured per-protocol reports
- Changed popup handling to consistently use custom GUI dialogs with native fallback
- Fixed duplicate Enter popup activation and Credits editability edge cases
- Improved WebDAV storage-size detection with multiple quota fallback methods

## Release Note Files

- [release_notes_1.5.2.md](release_notes_1.5.2.md)
- [release_notes_1.5.0.md](release_notes_1.5.0.md)
- [release_notes_1.4.1.7.md](release_notes_1.4.1.7.md)
- [release_notes_1.4.1.6.md](release_notes_1.4.1.6.md)
- [release_notes_1.4.1.5.md](release_notes_1.4.1.5.md)
- [release_notes_1.4.1.3.md](release_notes_1.4.1.3.md)
- [release_notes_1.4.1.2.md](release_notes_1.4.1.2.md)
- [release_notes_1.3.0.md](release_notes_1.3.0.md)
- [release_notes_1.2.1.1.md](release_notes_1.2.1.1.md)
- [release_notes_1.2.1.md](release_notes_1.2.1.md)
