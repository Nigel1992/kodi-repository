import sys
import xbmc
import xbmcaddon
import xbmcgui
from resources.lib.backup_utils import BackupManager

def main():
    """Main entry point"""
    addon = xbmcaddon.Addon()
    backup_manager = BackupManager(addon)
    
    # Set author and version in settings
    addon.setSetting('author', 'Nigel1992')
    addon.setSetting('version', 'Version 1.5.0')
    
    # Get command line arguments
    if len(sys.argv) < 2:
        return
        
    command = sys.argv[1]
    
    if command == 'backup_now':
        success, message = backup_manager.create_backup()
        if success:
            backup_manager.show_last_operation_summary()
        else:
            xbmcgui.Dialog().ok(addon.getAddonInfo("name"), f"Backup failed: {message}")
    elif command == 'restore':
        success, message = backup_manager.restore_backup()
        if success:
            backup_manager.show_last_operation_summary()
        elif message not in ("Backup restore cancelled", "No backup files found"):
            xbmcgui.Dialog().ok(addon.getAddonInfo("name"), f"Restore failed: {message}")
    elif command == 'view':
        backup_manager.view_backups()
    elif command == 'test_connection':
        backup_manager.test_connection()
    elif command == 'test_email':
        backup_manager.test_email()
    elif command == 'browse_remote':
        backup_manager.browse_remote()
    elif command == 'rotation_warning':
        # Show warning dialog when enabling rotation
        addon = xbmcaddon.Addon()
        dialog = xbmcgui.Dialog()
        
        # Get the current setting value
        is_enabled = addon.getSettingBool('enable_rotation')
        
        # Only show warning if trying to enable
        if is_enabled:
            confirmed = dialog.yesno(
                "Warning",
                "Backup rotation will automatically delete old backups when enabled.\n\nAre you sure you want to continue?",
                nolabel="No, Disable",
                yeslabel="Yes, Enable"
            )
            
            if not confirmed:
                # User chose to disable rotation
                addon.setSetting('enable_rotation', 'false')
                xbmc.log("User disabled backup rotation after warning", xbmc.LOGINFO)
                dialog.notification(
                    addon.getAddonInfo("name"),
                    "Backup rotation has been disabled",
                    xbmcgui.NOTIFICATION_INFO,
                    5000
                )

if __name__ == '__main__':
    main() 