#!/usr/bin/python3
# -*- coding: utf-8 -*-

import os
import glob
import shutil
import xbmc
import xbmcaddon
import xbmcvfs
import subprocess
from datetime import datetime, timedelta
import zipfile
import json
import time
import gc  # Add garbage collector import
import re
import ftplib
import socket
import urllib.parse
import requests
import xml.etree.ElementTree as ET
import textwrap
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import xbmcgui
from .email_utils import EmailNotifier

try:
    from .custom_gui import ask_yesno, show_message, show_textviewer
except Exception:
    ask_yesno = None
    show_message = None
    show_textviewer = None


def popup_message(title, text):
    """Show an OK-style popup preferring custom GUI."""
    try:
        if show_message is not None:
            show_message(title, text)
        else:
            xbmcgui.Dialog().ok(title, text)
    except Exception:
        xbmcgui.Dialog().ok(title, text)


def popup_confirm(title, text, yes_label='Yes', no_label='No'):
    """Show a yes/no popup preferring custom GUI."""
    try:
        if ask_yesno is not None:
            return ask_yesno(title, text, yes_label=yes_label, no_label=no_label)
        return xbmcgui.Dialog().yesno(title, text, yeslabel=yes_label, nolabel=no_label)
    except Exception:
        try:
            return xbmcgui.Dialog().yesno(title, text, yeslabel=yes_label, nolabel=no_label)
        except Exception:
            return False


def popup_text(title, text):
    """Show a scrollable text popup preferring custom GUI."""
    try:
        if show_textviewer is not None:
            show_textviewer(title, text)
        elif show_message is not None:
            show_message(title, text)
        else:
            xbmcgui.Dialog().textviewer(title, text)
    except Exception:
        popup_message(title, text)

# Try to import paramiko, but don't fail if it's not available
try:
    import paramiko
    PARAMIKO_AVAILABLE = True
except ImportError:
    PARAMIKO_AVAILABLE = False
    xbmc.log("Paramiko module not available. SFTP functionality will be disabled.", xbmc.LOGWARNING)

class BackupManager:
    """Utility class to manage config backups"""
    
    def __init__(self, addon=None):
        self.addon = addon or xbmcaddon.Addon()
        self.verbose_logging = False
        self._refresh_logging_flag()
        self.update_backup_location()
        self._temp_files = set()  # Track temporary files
        self.remote_connection = None
        self._webdav_session = None  # Persistent WebDAV session
        self.temp_dir = None  # Initialize temp_dir
        self._cleanup_old_temp_files()  # Clean up any old temp files on startup
        self.progress_dialog = None  # Initialize progress dialog
        self.current_notification = None  # Track current notification
        self.email_notifier = EmailNotifier()
        self.last_operation_summary = None  # Holds last backup/restore summary for UI display

    def _refresh_logging_flag(self):
        """Refresh verbose logging flag from settings."""
        try:
            self.verbose_logging = self.addon.getSettingBool('enable_verbose_logging')
        except Exception:
            self.verbose_logging = False

    def _log(self, message, level=xbmc.LOGINFO):
        """Centralized logger that elevates debug to info when verbose is enabled."""
        try:
            safe_message = self.sanitize_string_encoding(str(message))
        except Exception:
            try:
                safe_message = str(message).encode('utf-8', errors='backslashreplace').decode('ascii', errors='ignore')
            except Exception:
                safe_message = "BackupManager: <unprintable log message>"

        target_level = xbmc.LOGINFO if self.verbose_logging and level == xbmc.LOGDEBUG else level
        try:
            xbmc.log(safe_message, target_level)
        except Exception:
            # Avoid recursive logging failures on malformed strings.
            try:
                xbmc.log("BackupManager: log message encoding failure", xbmc.LOGWARNING)
            except Exception:
                pass

    def log_verbose(self, context, **kwargs):
        """Emit detailed debug logging with structured context."""
        details = ", ".join([f"{k}={repr(v)}" for k, v in kwargs.items()]) if kwargs else ""
        self._log(f"BackupManager[{context}]: {details}", xbmc.LOGDEBUG)
    
    def update_backup_location(self):
        """Update backup location from settings"""
        self._refresh_logging_flag()
        self._log("BackupManager: Updating backup location settings", xbmc.LOGINFO)

        # Get backup location type from settings
        self.location_type = int(self.addon.getSetting('backup_location_type') or "0")
        self._log(f"BackupManager: Location type = {self.location_type} (0=Local, 1=Remote)", xbmc.LOGINFO)

        # Define paths for various Kodi directories
        self.kodi_home = xbmcvfs.translatePath('special://home')
        self.kodi_userdata = xbmcvfs.translatePath('special://userdata')
        self._log(f"BackupManager: Kodi paths - home: {self.kodi_home}, userdata: {self.kodi_userdata}", xbmc.LOGDEBUG)

        # Initialize backup_dir
        self.backup_dir = None
        # Reset remote password to a safe default each time we reload settings
        self.remote_password = ""

        # Handle local backup location
        if self.location_type == 0:  # Local
            self.backup_dir = self.addon.getSetting('backup_location')
            self._log(f"BackupManager: Local backup location setting: {self.backup_dir}", xbmc.LOGINFO)

            if not self.backup_dir:
                self.backup_dir = "/storage/backup"  # Default location
                self._log("BackupManager: Using default local backup location: /storage/backup", xbmc.LOGINFO)

            # Validate that local path doesn't contain network protocols or remote path formats
            if self.backup_dir and (self.backup_dir.startswith(('nfs:', 'smb:', 'ftp:', 'sftp:', 'http:', 'https:')) or '://' in self.backup_dir or ':' in self.backup_dir):
                self._log(f"BackupManager: Invalid local path detected (contains network protocol or remote path format): {self.backup_dir}", xbmc.LOGWARNING)
                # Reset to default if invalid
                self.backup_dir = "/storage/backup"
                self.addon.setSetting('backup_location', self.backup_dir)
                self._log("BackupManager: Reset backup location to default: /storage/backup", xbmc.LOGINFO)
            else:
                self._log(f"BackupManager: Local backup directory validated: {self.backup_dir}", xbmc.LOGINFO)
        else:  # Remote
            self._log("BackupManager: Configuring remote backup settings", xbmc.LOGINFO)

            # Get remote settings
            self.remote_type = int(self.addon.getSetting('remote_location_type') or "0")
            self.remote_path = self.addon.getSetting('remote_path')
            self.remote_username = self.addon.getSetting('remote_username')
            # Don't log actual password; just note whether one is set
            self.remote_password = self.addon.getSetting('remote_password')
            # Don't log password for security
            self.remote_port = int(self.addon.getSetting('remote_port') or "0")

            remote_type_names = ["SMB", "NFS", "FTP", "SFTP", "WebDAV"]
            remote_type_name = remote_type_names[self.remote_type] if self.remote_type < len(remote_type_names) else f"Unknown({self.remote_type})"

            self._log(f"BackupManager: Remote type = {self.remote_type} ({remote_type_name})", xbmc.LOGINFO)
            self._log(f"BackupManager: Remote path = {self.remote_path}", xbmc.LOGINFO)
            self._log(f"BackupManager: Remote username = {self.remote_username}", xbmc.LOGINFO)
            self._log(f"BackupManager: Remote password set: {'Yes' if self.remote_password else 'No'}", xbmc.LOGDEBUG)
            self._log(f"BackupManager: Remote port = {self.remote_port}", xbmc.LOGINFO)

            # Emit consolidated verbose state for easier troubleshooting
            self.log_verbose(
                "update_backup_location",
                location_type=self.location_type,
                remote_type=remote_type_name,
                remote_path=self.remote_path,
                remote_username=self.remote_username,
                remote_password_set=bool(self.remote_password),
                remote_port=self.remote_port,
            )

            # Set default ports if not specified
            if self.remote_port == 0:
                if self.remote_type == 0:  # SMB
                    self.remote_port = 445
                elif self.remote_type == 1:  # NFS
                    self.remote_port = 2049
                elif self.remote_type == 2:  # FTP
                    self.remote_port = 21
                elif self.remote_type == 3:  # SFTP
                    self.remote_port = 22
                elif self.remote_type == 4:  # WebDAV
                    self.remote_port = 80
                self._log(f"BackupManager: Set default port for {remote_type_name}: {self.remote_port}", xbmc.LOGINFO)

            # Create a temporary local directory for staging remote files
            self.backup_dir = os.path.join(xbmcvfs.translatePath('special://temp'), 'libreelec_backupper')
            self._log(f"BackupManager: Remote staging directory: {self.backup_dir}", xbmc.LOGINFO)

        # Ensure backup directory exists (only for remote backups where we create temp dirs)
        if self.location_type != 0:  # Remote
            if self.backup_dir and not os.path.exists(self.backup_dir):
                try:
                    os.makedirs(self.backup_dir)
                    self._log(f"BackupManager: Created staging directory: {self.backup_dir}", xbmc.LOGINFO)
                except Exception as e:
                    self._log(f"BackupManager: Error creating backup directory: {str(e)}", xbmc.LOGERROR)
                    # Fall back to addon profile if custom location can't be created
                    self.backup_dir = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
                    self._log(f"BackupManager: Falling back to addon profile directory: {self.backup_dir}", xbmc.LOGWARNING)
                    if not os.path.exists(self.backup_dir):
                        os.makedirs(self.backup_dir)
                        self._log("BackupManager: Created fallback directory", xbmc.LOGINFO)

        self._log(f"BackupManager: Final backup directory: {self.backup_dir}", xbmc.LOGINFO)
    
    def _create_webdav_session(self):
        """Create a WebDAV session with retry logic and connection pooling"""
        if self._webdav_session is not None:
            return self._webdav_session
            
        # Configure retry strategy
        retry_strategy = Retry(
            total=3,  # number of retries
            backoff_factor=1,  # wait 1, 2, 4 seconds between retries
            status_forcelist=[429, 500, 502, 503, 504]  # retry on these status codes
        )
        
        # Create session with connection pooling
        session = requests.Session()
        adapter = HTTPAdapter(
            max_retries=retry_strategy,
            pool_connections=1,  # maintain one connection in the pool
            pool_maxsize=1,  # max number of connections in the pool
            pool_block=False  # don't block when pool is full
        )
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        if self.remote_username:
            session.auth = (self.remote_username, self.remote_password)
            
        self._webdav_session = session
        # Cache for last WebDAV listing (filename -> info)
        self._last_webdav_listing = {}
        return session

    def connect_remote(self):
        """Connect to the remote location"""
        if self.location_type == 0:  # Local
            return True
        
        try:
            self._log("BackupManager: Starting remote connection", xbmc.LOGINFO)
            self.log_verbose(
                "connect_remote:start",
                remote_type=self.remote_type,
                remote_path=self.remote_path,
                remote_username=self.remote_username,
                remote_password_set=bool(self.remote_password),
                remote_port=self.remote_port,
            )
            if self.remote_type == 0:  # SMB
                # Use Kodi's built-in SMB support via xbmcvfs
                # Construct SMB URL properly
                # remote_path is in format: server/share
                # Convert to: smb://server/share
                smb_path = self.remote_path.replace(':', '/')  # Just in case there's still a colon
                if self.remote_username and self.remote_password:
                    remote_url = f"smb://{self.remote_username}:{urllib.parse.quote(self.remote_password)}@{smb_path}"
                elif self.remote_type == 4:  # WebDAV
                    # List files via WebDAV
                    base = self.remote_connection.get('base_url') if isinstance(self.remote_connection, dict) else None
                    session = self.remote_connection.get('session') if isinstance(self.remote_connection, dict) else None
                    self._log(f"Listing WebDAV files from: {base}", xbmc.LOGINFO)
                    self._log(f"Using WebDAV credentials: username={self.remote_username}, password=****************", xbmc.LOGDEBUG)

                    if not session or not base:
                        self._log("BackupManager: WebDAV session or base_url missing", xbmc.LOGERROR)
                        return []

                    try:
                        response = session.request('PROPFIND', base, headers={'Depth': '1'})
                    except Exception as e:
                        self._log(f"BackupManager: WebDAV PROPFIND request failed: {str(e)}", xbmc.LOGERROR)
                        return []

                    self._log(f"WebDAV PROPFIND response status: {response.status_code}", xbmc.LOGINFO)
                    self._log(f"WebDAV response headers: {dict(response.headers)}", xbmc.LOGDEBUG)
                    self._log(f"Raw response text: {response.text}", xbmc.LOGDEBUG)

                    # Accept both 207 (Multi-Status) and 200 OK responses
                    if response.status_code not in (207, 200):
                        self._log(f"WebDAV PROPFIND failed with status code: {response.status_code}", xbmc.LOGERROR)
                        self._log(f"WebDAV response: {response.text}", xbmc.LOGERROR)
                        return []

                    files = []
                    try:
                        # Parse XML response robustly using ElementTree and namespace-agnostic matching
                        root = ET.fromstring(response.content)
                        for elem in root.iter():
                            tag = elem.tag
                            local = tag.split('}', 1)[1] if '}' in tag else tag
                            if local.lower() == 'href':
                                href = elem.text or ''
                                # Extract filename from href path
                                parsed = urllib.parse.urlparse(href)
                                path = parsed.path or href
                                name = os.path.basename(path.rstrip('/'))
                                if not name:
                                    continue
                                name = urllib.parse.unquote(name)
                                if name.endswith('.zip') and name not in files:
                                    files.append(name)
                            elif local.lower() == 'displayname':
                                name = (elem.text or '').strip()
                                if name.endswith('.zip') and name not in files:
                                    files.append(name)
                    except Exception as e:
                        self._log(f"BackupManager: Failed to parse WebDAV PROPFIND response: {str(e)}", xbmc.LOGERROR)
                        self._log(f"Response text: {response.text}", xbmc.LOGDEBUG)
                        return []

                    self._log(f"Final list of backup files found: {files}", xbmc.LOGINFO)
                    self._log(f"Found {len(files)} backup files via WebDAV", xbmc.LOGINFO)
                    return files
                    self._log(error_msg, xbmc.LOGERROR)
                    return False
                
            elif self.remote_type == 2:  # FTP
                # Connect to FTP server
                ftp = ftplib.FTP()
                ftp.connect(self.remote_path.split('/')[0], self.remote_port)
                ftp.login(self.remote_username, self.remote_password)
                
                # Change to the specified directory if provided
                if '/' in self.remote_path:
                    remote_dir = '/'.join(self.remote_path.split('/')[1:])
                    if remote_dir:
                        ftp.cwd(remote_dir)
                
                self.remote_connection = ftp
                return True
                
            elif self.remote_type == 3:  # SFTP
                # Check if paramiko is available
                if not PARAMIKO_AVAILABLE:
                    self._log("Cannot use SFTP: Paramiko module not available", xbmc.LOGERROR)
                    return False
                
                # Connect to SFTP server
                ssh = paramiko.SSHClient()
                ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                
                host = self.remote_path.split('/')[0]
                ssh.connect(host, port=self.remote_port, username=self.remote_username, password=self.remote_password)
                
                sftp = ssh.open_sftp()
                
                # Change to the specified directory if provided
                if '/' in self.remote_path:
                    remote_dir = '/'.join(self.remote_path.split('/')[1:])
                    if remote_dir:
                        sftp.chdir(remote_dir)
                
                self.remote_connection = sftp
                return True
                
            elif self.remote_type == 4:  # WebDAV
                # Use the entire WebDAV URL from settings
                webdav_url = self.remote_path
                if not webdav_url.startswith(('http://', 'https://')):
                    # For Koofr, we need to use the correct WebDAV URL format
                    if 'koofr.net' in webdav_url:
                        # Extract the path components
                        parts = webdav_url.split('/')
                        if len(parts) >= 4:
                            # Construct the proper Koofr WebDAV URL
                            webdav_url = f"https://{parts[0]}/dav/{parts[2]}/{parts[3]}"
                            if len(parts) > 4:
                                webdav_url += '/' + '/'.join(parts[4:])
                    else:
                        # For other WebDAV servers, use standard format
                        webdav_url = f"https://{webdav_url}" if self.remote_port == 443 else f"http://{webdav_url}"
                
                if not webdav_url.endswith('/'):
                    webdav_url += '/'
                self._log(f"BackupManager: Testing WebDAV connection to: {webdav_url}", xbmc.LOGINFO)
                
                # Get or create WebDAV session
                try:
                    session = self._create_webdav_session()
                    self._log("BackupManager: WebDAV session created successfully", xbmc.LOGINFO)
                except Exception as e:
                    self._log(f"BackupManager: Failed to create WebDAV session: {str(e)}", xbmc.LOGERROR)
                    return False
                
                # Set credentials if provided
                if self.remote_username and self.remote_password:
                    try:
                        session.auth = (self.remote_username, self.remote_password)
                        self._log("WebDAV credentials set successfully", xbmc.LOGINFO)
                    except Exception as e:
                        self._log(f"Failed to set WebDAV credentials: {str(e)}", xbmc.LOGERROR)
                        return False
                
                # Test connection with retry logic
                try:
                    self._log(f"Testing WebDAV connection to: {webdav_url}", xbmc.LOGINFO)
                    response = session.request('PROPFIND', webdav_url, headers={'Depth': '1'})
                    self._log(f"BackupManager: WebDAV response status: {response.status_code}", xbmc.LOGINFO)
                    self._log(f"BackupManager: WebDAV response headers: {dict(response.headers)}", xbmc.LOGDEBUG)
                    self._log(f"BackupManager: WebDAV response text: {response.text}", xbmc.LOGDEBUG)
                    
                    if response.status_code in [207, 200]:  # 207 is Multi-Status response
                        self.remote_connection = {
                            'session': session,
                            'base_url': webdav_url
                        }
                        self._log("BackupManager: WebDAV connection successful", xbmc.LOGINFO)
                        return True
                    else:
                        self._log(f"BackupManager: WebDAV connection failed with status code: {response.status_code}", xbmc.LOGERROR)
                        self._log(f"BackupManager: WebDAV response: {response.text}", xbmc.LOGERROR)
                        return False
                except requests.exceptions.RetryError as e:
                    self._log(f"BackupManager: WebDAV connection failed after retries: {str(e)}", xbmc.LOGERROR)
                    return False
                except requests.exceptions.RequestException as e:
                    self._log(f"BackupManager: WebDAV request failed: {str(e)}", xbmc.LOGERROR)
                    return False
                except Exception as e:
                    self._log(f"BackupManager: Unexpected error during WebDAV connection: {str(e)}", xbmc.LOGERROR)
                    return False
                
        except Exception as e:
            self._log(f"Error connecting to remote location: {str(e)}", xbmc.LOGERROR)
            self.log_verbose("connect_remote:error", error=str(e))
            return False
    
    def disconnect_remote(self):
        """Disconnect from the remote location"""
        if self.location_type == 0 or not self.remote_connection:  # Local or not connected
            return
        
        try:
            if self.remote_type == 0:  # SMB
                # Nothing to disconnect for SMB via xbmcvfs
                self.remote_connection = None
                
            elif self.remote_type == 1:  # NFS
                # Unmount NFS share
                mount_point = self.remote_connection
                subprocess.call(["umount", mount_point], stderr=subprocess.DEVNULL)
                self.remote_connection = None
                
            elif self.remote_type == 2:  # FTP
                # Close FTP connection
                self.remote_connection.quit()
                self.remote_connection = None
                
            elif self.remote_type == 3:  # SFTP
                # Close SFTP connection
                self.remote_connection.close()
                self.remote_connection.get_channel().get_transport().close()
                self.remote_connection = None
                
            elif self.remote_type == 4:  # WebDAV
                # Don't close the session, just clear the connection info
                self.remote_connection = None
                
        except Exception as e:
            self._log(f"Error disconnecting from remote location: {str(e)}", xbmc.LOGERROR)
    
    def get_remote_path(self, filename):
        """Get the full path to a file on the remote location"""
        if self.location_type == 0:  # Local
            return os.path.join(self.backup_dir, filename)
        
        if self.remote_type == 0:  # SMB
            if self.remote_connection.endswith('/'):
                return f"{self.remote_connection}{filename}"
            else:
                return f"{self.remote_connection}/{filename}"
                
        elif self.remote_type == 1:  # NFS
            return os.path.join(self.remote_connection, filename)
                
        elif self.remote_type in [2, 3]:  # FTP or SFTP
            return filename  # Just return the filename for FTP/SFTP
            
        elif self.remote_type == 4:  # WebDAV
            base_url = self.remote_connection['base_url']
            if base_url.endswith('/'):
                return f"{base_url}{filename}"
            else:
                return f"{base_url}/{filename}"
    
    def upload_file(self, local_path, remote_filename):
        """Upload a file to the remote location"""
        try:
            if not os.path.exists(local_path):
                self._log(f"BackupManager: Upload aborted missing local file {local_path}", xbmc.LOGERROR)
                return False

            file_size = os.path.getsize(local_path)
            file_size_str = self.format_size(file_size)
            self._log(f"BackupManager: Upload start local={local_path} remote={remote_filename} size={file_size_str}", xbmc.LOGINFO)
            
            # Show initial upload notification
            self.notify("Uploading backup...", persistent=True)
            self.update_progress(0, "Uploading backup...", f"Size: {file_size_str}")

            if self.remote_type == 0:  # SMB
                remote_path = self.get_remote_path(remote_filename)
                self._log(f"BackupManager: SMB upload to {remote_path}", xbmc.LOGINFO)
                with open(local_path, 'rb') as local_file:
                    with xbmcvfs.File(remote_path, 'wb') as remote_file:
                        bytes_uploaded = 0
                        last_update = time.time()
                        update_interval = 0.5  # Update every 0.5 seconds
                        chunk_size = 8192  # 8KB chunks
                        
                        while True:
                            chunk = local_file.read(chunk_size)
                            if not chunk:
                                break
                                
                            remote_file.write(chunk)
                            bytes_uploaded += len(chunk)
                            current_time = time.time()
                            
                            if current_time - last_update >= update_interval:
                                progress = int((bytes_uploaded / file_size) * 100)
                                uploaded_str = self.format_size(bytes_uploaded)
                                
                                # Update progress dialog only
                                self.update_progress(
                                    progress,
                                    "Uploading backup...",
                                    f"{uploaded_str} / {file_size_str}"
                                )
                                
                                last_update = current_time
                
            elif self.remote_type == 1:  # NFS
                if not self.remote_connection:
                    return False
                dest_path = os.path.join(self.remote_connection, remote_filename)
                self._log(f"BackupManager: NFS upload dest={dest_path}", xbmc.LOGINFO)
                self.buffered_copy(local_path, dest_path, file_size, 0, file_size)
                
            elif self.remote_type == 2:  # FTP
                if not self.remote_connection:
                    return False
                    
                with open(local_path, 'rb') as local_file:
                    self._log(f"BackupManager: FTP STOR {remote_filename}", xbmc.LOGINFO)
                    self.remote_connection.storbinary(
                        f'STOR {remote_filename}',
                        local_file,
                        callback=lambda sent: self._upload_progress_callback(sent, file_size)
                    )
                
            elif self.remote_type == 3:  # SFTP
                if not self.remote_connection:
                    return False
                    
                self._log(f"BackupManager: SFTP upload {remote_filename}", xbmc.LOGINFO)
                def progress_callback(sent, total):
                    self._upload_progress_callback(sent, total)
                
                self.remote_connection.put(local_path, remote_filename, callback=progress_callback)
                
            elif self.remote_type == 4:  # WebDAV
                if not self.remote_connection:
                    return False
                    
                url = self.remote_connection['base_url'].rstrip('/') + '/' + remote_filename
                session = self.remote_connection['session']
                self._log(f"BackupManager: WebDAV PUT {url}", xbmc.LOGINFO)
                
                with open(local_path, 'rb') as local_file:
                    response = session.put(url, data=self._create_upload_generator(local_file, file_size))
                    
                if response.status_code not in [200, 201, 204]:
                    self._log(f"BackupManager: WebDAV upload failed status={response.status_code} text={response.text}", xbmc.LOGERROR)
                    return False

            # Show completion notification
            self.notify("Upload complete", persistent=True)
            self.update_progress(100, "Upload complete")
            self._log("BackupManager: Upload finished", xbmc.LOGINFO)
            return True
                
        except Exception as e:
            self._log(f"Error uploading file: {str(e)}", xbmc.LOGERROR)
            return False
            
    def _upload_progress_callback(self, sent, total):
        """Callback for upload progress"""
        progress = int((sent / total) * 100)
        sent_str = self.format_size(sent)
        total_str = self.format_size(total)
        
        # Update progress dialog only
        self.update_progress(
            progress,
            "Uploading backup...",
            f"{sent_str} / {total_str}"
        )
        
    def _create_upload_generator(self, file_obj, total_size):
        """Create a generator for uploading files with progress tracking"""
        bytes_uploaded = 0
        chunk_size = 8192  # 8KB chunks
        last_update = time.time()
        update_interval = 0.5  # Update every 0.5 seconds
        
        while True:
            chunk = file_obj.read(chunk_size)
            if not chunk:
                break
                
            bytes_uploaded += len(chunk)
            current_time = time.time()
            
            if current_time - last_update >= update_interval:
                self._upload_progress_callback(bytes_uploaded, total_size)
                last_update = current_time
                
            yield chunk
    
    def download_file(self, remote_filename, local_path):
        """Download a file from the remote location"""
        if self.location_type == 0:  # Local
            # Just copy the file from the backup directory
            source_path = os.path.join(self.backup_dir, remote_filename)
            shutil.copy2(source_path, local_path)
            return True
        
        try:
            if self.remote_type == 0:  # SMB
                # Use xbmcvfs to copy the file
                remote_path = self.get_remote_path(remote_filename)
                return xbmcvfs.copy(remote_path, local_path)
                
            elif self.remote_type == 1:  # NFS
                # Copy the file from the mounted directory
                remote_path = self.get_remote_path(remote_filename)
                shutil.copy2(remote_path, local_path)
                return True
                
            elif self.remote_type == 2:  # FTP
                # Download the file via FTP
                with open(local_path, 'wb') as f:
                    self.remote_connection.retrbinary(f'RETR {remote_filename}', f.write)
                return True
                
            elif self.remote_type == 3:  # SFTP
                # Download the file via SFTP
                self.remote_connection.get(remote_filename, local_path)
                return True
                
            elif self.remote_type == 4:  # WebDAV
                # Download the file via WebDAV
                remote_url = self.get_remote_path(remote_filename)
                response = self.remote_connection['session'].get(remote_url, stream=True)
                if response.status_code == 200:
                    with open(local_path, 'wb') as f:
                        for chunk in response.iter_content(chunk_size=8192):
                            f.write(chunk)
                    return True
                return False
                
        except Exception as e:
            self._log(f"Error downloading file from remote location: {str(e)}", xbmc.LOGERROR)
            return False
    
    def list_remote_files(self):
        """List files in the remote location"""
        if self.location_type == 0:  # Local
            # Just list files in the backup directory
            return [f for f in os.listdir(self.backup_dir) if os.path.isfile(os.path.join(self.backup_dir, f))]
        
        try:
            if self.remote_type == 0:  # SMB
                # Use xbmcvfs to list files
                self._log(f"Listing SMB files from: {self.remote_connection}", xbmc.LOGINFO)
                _, files = xbmcvfs.listdir(self.remote_connection)
                self._log(f"Found {len(files)} files via SMB", xbmc.LOGINFO)
                return files
                
            elif self.remote_type == 1:  # NFS
                # List files in the mounted directory
                self._log(f"Listing NFS files from: {self.remote_connection}", xbmc.LOGINFO)
                files = [f for f in os.listdir(self.remote_connection) if os.path.isfile(os.path.join(self.remote_connection, f))]
                self._log(f"Found {len(files)} files via NFS", xbmc.LOGINFO)
                return files
                
            elif self.remote_type == 2:  # FTP
                # List files via FTP
                self._log(f"Listing FTP files", xbmc.LOGINFO)
                files = self.remote_connection.nlst()
                # Filter out directories and hidden files
                files = [f for f in files if not f.startswith('.') and not self.is_remote_dir(f)]
                self._log(f"Found {len(files)} files via FTP", xbmc.LOGINFO)
                return files
                
            elif self.remote_type == 3:  # SFTP
                # List files via SFTP
                self._log(f"Listing SFTP files", xbmc.LOGINFO)
                files = [f for f in self.remote_connection.listdir() if not self.is_remote_dir(f)]
                self._log(f"Found {len(files)} files via SFTP", xbmc.LOGINFO)
                return files
                
            elif self.remote_type == 4:  # WebDAV
                # List files via WebDAV using robust XML parsing
                base = self.remote_connection.get('base_url') if isinstance(self.remote_connection, dict) else None
                session = self.remote_connection.get('session') if isinstance(self.remote_connection, dict) else None
                self._log(f"Listing WebDAV files from: {base}", xbmc.LOGINFO)
                self._log(f"Using WebDAV credentials: username={self.remote_username}, password=****************", xbmc.LOGDEBUG)

                if not session or not base:
                    self._log("BackupManager: WebDAV session or base_url missing", xbmc.LOGERROR)
                    return []

                try:
                    response = session.request('PROPFIND', base, headers={'Depth': '1'})
                except Exception as e:
                    self._log(f"BackupManager: WebDAV PROPFIND request failed: {str(e)}", xbmc.LOGERROR)
                    return []

                self._log(f"WebDAV PROPFIND response status: {response.status_code}", xbmc.LOGINFO)
                self._log(f"WebDAV response headers: {dict(response.headers)}", xbmc.LOGDEBUG)
                self._log(f"Raw response text: {response.text}", xbmc.LOGDEBUG)

                # Accept both 207 (Multi-Status) and 200 OK responses
                if response.status_code not in (207, 200):
                    self._log(f"WebDAV PROPFIND failed with status code: {response.status_code}", xbmc.LOGERROR)
                    self._log(f"WebDAV response: {response.text}", xbmc.LOGERROR)
                    return []

                files = []
                try:
                    # Parse PROPFIND Multi-Status response and extract per-response details
                    root = ET.fromstring(response.content)
                    # Reset cached listing
                    self._last_webdav_listing = {}

                    for resp in root.findall('.//{DAV:}response'):
                        try:
                            href_elem = resp.find('{DAV:}href')
                            if href_elem is None or not href_elem.text:
                                continue
                            href = href_elem.text
                            parsed = urllib.parse.urlparse(href)
                            path = parsed.path or href
                            name = os.path.basename(path.rstrip('/'))
                            if not name:
                                continue
                            name = urllib.parse.unquote(name)

                            # Attempt to read getcontentlength and getlastmodified
                            size = None
                            mtime = None
                            size_elem = resp.find('.//{DAV:}getcontentlength')
                            if size_elem is not None and size_elem.text:
                                try:
                                    size = int(size_elem.text)
                                except Exception:
                                    size = None

                            mtime_elem = resp.find('.//{DAV:}getlastmodified')
                            if mtime_elem is not None and mtime_elem.text:
                                try:
                                    from email.utils import parsedate_to_datetime
                                    dt = parsedate_to_datetime(mtime_elem.text)
                                    mtime = dt.timestamp()
                                except Exception:
                                    mtime = None

                            if name.endswith('.zip'):
                                if name not in files:
                                    files.append(name)
                                # Cache info
                                self._last_webdav_listing[name] = {
                                    'size': size,
                                    'mtime': mtime,
                                    'href': href
                                }
                        except Exception:
                            continue
                except Exception as e:
                    self._log(f"BackupManager: Failed to parse WebDAV PROPFIND response: {str(e)}", xbmc.LOGERROR)
                    self._log(f"Response text: {response.text}", xbmc.LOGDEBUG)
                    return []

                self._log(f"Final list of backup files found: {files}", xbmc.LOGINFO)
                self._log(f"Found {len(files)} backup files via WebDAV", xbmc.LOGINFO)
                return files
                
        except Exception as e:
            self._log(f"Error listing files in remote location: {str(e)}", xbmc.LOGERROR)
            import traceback
            self._log(f"Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
            return []
    
    def is_remote_dir(self, path):
        """Check if a path on the remote location is a directory"""
        if self.remote_type == 3:  # SFTP
            try:
                return self.remote_connection.stat(path).st_mode & 0o40000 != 0
            except:
                return False
        return False

    def get_remote_file_info(self, filename):
        """Return cached or fetched info for a remote file (size, mtime, href).

        Returns a dict with keys: 'size' (int or None), 'mtime' (epoch or None), 'href' (str or None)
        """
        try:
            if self.location_type == 0:
                local_path = os.path.join(self.backup_dir, filename)
                if os.path.exists(local_path):
                    return {'size': os.path.getsize(local_path), 'mtime': os.path.getmtime(local_path), 'href': local_path}
                return {'size': None, 'mtime': None, 'href': local_path}

            if self.remote_type == 4:
                # Check cached listing first
                if hasattr(self, '_last_webdav_listing') and filename in self._last_webdav_listing:
                    return self._last_webdav_listing.get(filename, {})

                # Attempt to fetch file-specific PROPFIND (Depth: 0)
                try:
                    session = self._create_webdav_session()
                    base = self.remote_connection.get('base_url') if isinstance(self.remote_connection, dict) else None
                    if not base:
                        return {}
                    file_url = base.rstrip('/') + '/' + urllib.parse.quote(filename)
                    response = session.request('PROPFIND', file_url, headers={'Depth': '0'})
                    if response.status_code not in (200, 207):
                        return {}

                    root = ET.fromstring(response.content)
                    for resp in root.findall('.//{DAV:}response'):
                        href_elem = resp.find('{DAV:}href')
                        if href_elem is None or not href_elem.text:
                            continue
                        href = href_elem.text
                        parsed = urllib.parse.urlparse(href)
                        path = parsed.path or href
                        name = os.path.basename(path.rstrip('/'))
                        name = urllib.parse.unquote(name)
                        if name != filename:
                            continue

                        size = None
                        mtime = None
                        size_elem = resp.find('.//{DAV:}getcontentlength')
                        if size_elem is not None and size_elem.text:
                            try:
                                size = int(size_elem.text)
                            except Exception:
                                size = None
                        mtime_elem = resp.find('.//{DAV:}getlastmodified')
                        if mtime_elem is not None and mtime_elem.text:
                            try:
                                from email.utils import parsedate_to_datetime
                                dt = parsedate_to_datetime(mtime_elem.text)
                                mtime = dt.timestamp()
                            except Exception:
                                mtime = None

                        info = {'size': size, 'mtime': mtime, 'href': href}
                        # Cache
                        if not hasattr(self, '_last_webdav_listing'):
                            self._last_webdav_listing = {}
                        self._last_webdav_listing[name] = info
                        return info
                except Exception as e:
                    self._log(f"BackupManager: Error fetching WebDAV file info: {str(e)}", xbmc.LOGERROR)
                    return {}

            # Fallback for other remote types: return empty info
            return {}
        except Exception as e:
            self._log(f"get_remote_file_info error: {str(e)}", xbmc.LOGERROR)
            return {}

    def _extract_xml_int_by_local_name(self, xml_root, local_names):
        """Return the first integer XML value matching one of the local tag names."""
        try:
            wanted = {str(name).lower() for name in local_names}
            values = []
            for elem in xml_root.iter():
                tag = elem.tag
                local = tag.split('}', 1)[1] if '}' in tag else tag
                if str(local).lower() not in wanted:
                    continue
                raw = (elem.text or '').strip()
                if not raw:
                    continue
                parsed = self._parse_storage_int(raw)
                if parsed is not None:
                    values.append(parsed)
        except Exception:
            pass
        return max(values) if values else None

    def _parse_storage_int(self, raw_value):
        """Parse storage byte values from XML/header strings in a tolerant way."""
        try:
            text = str(raw_value).strip()
            if not text:
                return None

            lowered = text.lower()
            if lowered in ('none', 'unknown', 'unlimited', 'infinite', 'nan', '-'):
                return None

            # Handle values like "123,456" or "123 456" or "123.0".
            cleaned = text.replace(',', '').replace(' ', '')
            match = re.search(r'-?\d+(?:\.\d+)?', cleaned)
            if not match:
                return None

            value = int(float(match.group(0)))
            if value < 0:
                # Some servers return negative sentinels for unlimited/unknown quota.
                return None
            return value
        except Exception:
            return None

    def _build_webdav_probe_urls(self, base_url, max_levels=3):
        """Build a small set of candidate URLs (base, parent, root) for quota probes."""
        try:
            parsed = urllib.parse.urlsplit(base_url)
            path = parsed.path or '/'
            if not path.startswith('/'):
                path = '/' + path

            segments = [seg for seg in path.split('/') if seg]
            urls = []

            for idx in range(len(segments), -1, -1):
                candidate_path = '/' + '/'.join(segments[:idx])
                if not candidate_path.endswith('/'):
                    candidate_path += '/'
                candidate = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, candidate_path, '', ''))
                if candidate not in urls:
                    urls.append(candidate)
                if len(urls) >= max_levels:
                    break

            root_url = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, '/', '', ''))
            if root_url not in urls and len(urls) < max_levels:
                urls.append(root_url)

            return urls if urls else [base_url]
        except Exception:
            return [base_url]

    def _extract_webdav_quota_from_headers(self, headers):
        """Try to parse quota values from response headers."""
        try:
            if not headers:
                return {}

            normalized = {str(k).lower(): v for k, v in headers.items()}

            def get_first(keys):
                for key in keys:
                    if key in normalized:
                        parsed = self._parse_storage_int(normalized.get(key))
                        if parsed is not None:
                            return parsed
                return None

            used_bytes = get_first([
                'x-quota-used-bytes',
                'x-account-disk-usage',
                'x-storage-used',
                'x-disk-usage',
            ])
            free_bytes = get_first([
                'x-quota-available-bytes',
                'x-storage-free',
                'x-disk-free',
            ])
            total_bytes = get_first([
                'x-quota-total-bytes',
                'x-account-disk-limit',
                'x-storage-total',
                'x-disk-total',
            ])

            result = {
                'used_bytes': used_bytes,
                'free_bytes': free_bytes,
                'total_bytes': total_bytes,
            }
            if used_bytes is None and free_bytes is None and total_bytes is None:
                return {}
            return result
        except Exception:
            return {}

    def _parse_webdav_quota_from_response(self, response, source_name):
        """Extract quota values from a WebDAV response body and headers."""
        quota = {
            'used_bytes': None,
            'free_bytes': None,
            'total_bytes': None,
            'source': source_name,
        }

        try:
            xml_root = ET.fromstring(response.content)
            quota['used_bytes'] = self._extract_xml_int_by_local_name(
                xml_root,
                {
                    'quota-used-bytes',
                    'quotaused',
                    'quota-used',
                    'quota_used_bytes',
                },
            )
            quota['free_bytes'] = self._extract_xml_int_by_local_name(
                xml_root,
                {
                    'quota-available-bytes',
                    'quotaavailable',
                    'quota-available',
                    'quota-free-bytes',
                    'quota_available_bytes',
                },
            )
            quota['total_bytes'] = self._extract_xml_int_by_local_name(
                xml_root,
                {
                    'quota',
                    'quota-total-bytes',
                    'quota-total',
                    'quota_total_bytes',
                },
            )
        except Exception:
            # Some servers return no XML body for certain methods; headers may still help.
            pass

        header_quota = self._extract_webdav_quota_from_headers(getattr(response, 'headers', None))
        for key in ('used_bytes', 'free_bytes', 'total_bytes'):
            if quota.get(key) is None and header_quota.get(key) is not None:
                quota[key] = header_quota.get(key)

        used_bytes = quota.get('used_bytes')
        free_bytes = quota.get('free_bytes')
        total_bytes = quota.get('total_bytes')

        if total_bytes is None and used_bytes is not None and free_bytes is not None:
            total_bytes = used_bytes + free_bytes
        if total_bytes is not None and used_bytes is None and free_bytes is not None:
            used_bytes = max(total_bytes - free_bytes, 0)
        if total_bytes is not None and free_bytes is None and used_bytes is not None:
            free_bytes = max(total_bytes - used_bytes, 0)

        if total_bytes is not None and used_bytes is not None and used_bytes > total_bytes:
            used_bytes = None
        if total_bytes is not None and free_bytes is not None and free_bytes > total_bytes:
            free_bytes = None

        quota['used_bytes'] = used_bytes
        quota['free_bytes'] = free_bytes
        quota['total_bytes'] = total_bytes

        if used_bytes is None and free_bytes is None and total_bytes is None:
            return {}
        return quota

    def _get_webdav_quota_status(self):
        """Best-effort WebDAV quota lookup using multiple methods."""
        try:
            session = self.remote_connection.get('session') if isinstance(self.remote_connection, dict) else None
            base = self.remote_connection.get('base_url') if isinstance(self.remote_connection, dict) else None
            if not session or not base:
                return {}

            propfind_body = (
                "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
                "<d:propfind xmlns:d=\"DAV:\" xmlns:oc=\"http://owncloud.org/ns\" xmlns:nc=\"http://nextcloud.org/ns\">"
                "<d:prop>"
                "<d:quota-used-bytes/><d:quota-available-bytes/><d:quota/><d:quotaused/>"
                "<oc:quota-used-bytes/><oc:quota-available-bytes/><oc:quota/>"
                "<nc:quota-used-bytes/><nc:quota-available-bytes/><nc:quota/>"
                "</d:prop>"
                "</d:propfind>"
            )

            best_result = {}

            def score(candidate):
                if not candidate:
                    return 0
                result = 0
                if isinstance(candidate.get('total_bytes'), int):
                    result += 4
                if isinstance(candidate.get('used_bytes'), int):
                    result += 2
                if isinstance(candidate.get('free_bytes'), int):
                    result += 2
                return result

            probe_urls = self._build_webdav_probe_urls(base)
            for idx, probe_url in enumerate(probe_urls):
                depths = ('0', '1') if idx == 0 else ('0',)
                for depth in depths:
                    try:
                        response = session.request(
                            'PROPFIND',
                            probe_url,
                            headers={
                                'Depth': depth,
                                'Content-Type': 'text/xml; charset=utf-8',
                            },
                            data=propfind_body,
                        )
                    except Exception:
                        continue

                    if response.status_code not in (200, 207):
                        continue

                    candidate = self._parse_webdav_quota_from_response(
                        response,
                        f'webdav-propfind-d{depth}',
                    )
                    if score(candidate) > score(best_result):
                        best_result = candidate
                    if isinstance(candidate.get('total_bytes'), int):
                        return candidate

                # Header-only fallback for servers that expose quota in custom headers.
                try:
                    head_response = session.request('HEAD', probe_url)
                    if head_response.status_code in (200, 204, 207):
                        header_candidate = self._extract_webdav_quota_from_headers(head_response.headers)
                        if header_candidate:
                            header_candidate['source'] = 'webdav-head-headers'
                            if score(header_candidate) > score(best_result):
                                best_result = header_candidate
                            if isinstance(header_candidate.get('total_bytes'), int):
                                return header_candidate
                except Exception:
                    pass

            return best_result
        except Exception as e:
            self._log(f"BackupManager: Unable to read WebDAV quota info: {str(e)}", xbmc.LOGWARNING)
            return {}

    def _get_remote_file_size_bytes(self, filename):
        """Best-effort remote file size lookup across supported protocols."""
        try:
            info = self.get_remote_file_info(filename)
            if isinstance(info, dict):
                size = info.get('size')
                if isinstance(size, int) and size >= 0:
                    return size
        except Exception:
            pass

        try:
            if self.remote_type == 2 and self.remote_connection:  # FTP
                size = self.remote_connection.size(filename)
                if size is not None:
                    return int(size)
            elif self.remote_type == 3 and self.remote_connection:  # SFTP
                return int(self.remote_connection.stat(filename).st_size)
            elif self.remote_type == 1 and isinstance(self.remote_connection, str):  # NFS mount path
                file_path = os.path.join(self.remote_connection, filename)
                if os.path.exists(file_path):
                    return int(os.path.getsize(file_path))
            elif self.remote_type == 0 and self.remote_connection:  # SMB
                remote_path = self.get_remote_path(filename)
                stat_obj = xbmcvfs.Stat(remote_path)
                if hasattr(stat_obj, 'st_size'):
                    size_attr = getattr(stat_obj, 'st_size')
                    size = size_attr() if callable(size_attr) else size_attr
                    if size is not None:
                        return int(size)
        except Exception:
            pass

        return None

    def get_remote_storage_status(self, backup_files=None):
        """Return best-effort remote storage stats for dashboard system status.

        Keys in returned dict:
        - used_bytes: remote used bytes (when available)
        - free_bytes: remote free bytes (when available)
        - total_bytes: remote total bytes (when available)
        - backups_bytes: bytes used by known backup zip files
        - source: where quota values came from
        """
        status = {
            'used_bytes': None,
            'free_bytes': None,
            'total_bytes': None,
            'backups_bytes': 0,
            'source': 'unknown',
        }

        if self.location_type == 0:
            return status

        try:
            if not self.connect_remote():
                return status

            # Protocol-specific storage quota lookups.
            if self.remote_type == 4:  # WebDAV
                status.update(self._get_webdav_quota_status())
            elif self.remote_type == 3 and self.remote_connection and hasattr(self.remote_connection, 'statvfs'):
                try:
                    stat = self.remote_connection.statvfs('.')
                    block_size = int(getattr(stat, 'f_frsize', 0) or getattr(stat, 'f_bsize', 0) or 0)
                    blocks_total = int(getattr(stat, 'f_blocks', 0) or 0)
                    blocks_avail = int(getattr(stat, 'f_bavail', 0) or 0)
                    if block_size > 0 and blocks_total > 0:
                        total_bytes = blocks_total * block_size
                        free_bytes = max(blocks_avail * block_size, 0)
                        used_bytes = max(total_bytes - free_bytes, 0)
                        status.update({
                            'used_bytes': used_bytes,
                            'free_bytes': free_bytes,
                            'total_bytes': total_bytes,
                            'source': 'sftp-statvfs',
                        })
                except Exception as e:
                    self._log(f"BackupManager: Unable to read SFTP statvfs info: {str(e)}", xbmc.LOGWARNING)
            elif self.remote_type == 1 and isinstance(self.remote_connection, str):
                # NFS may be mounted to a local path; if so, statvfs can provide capacity.
                try:
                    if os.path.exists(self.remote_connection):
                        stat = os.statvfs(self.remote_connection)
                        total_bytes = int(stat.f_blocks) * int(stat.f_frsize)
                        free_bytes = int(stat.f_bavail) * int(stat.f_frsize)
                        used_bytes = max(total_bytes - free_bytes, 0)
                        status.update({
                            'used_bytes': used_bytes,
                            'free_bytes': free_bytes,
                            'total_bytes': total_bytes,
                            'source': 'nfs-statvfs',
                        })
                except Exception as e:
                    self._log(f"BackupManager: Unable to read NFS statvfs info: {str(e)}", xbmc.LOGWARNING)

            files = backup_files if backup_files is not None else self.list_remote_files()
            backup_bytes = 0
            for filename in files or []:
                name = str(filename)
                if not name.lower().endswith('.zip'):
                    continue
                size = self._get_remote_file_size_bytes(name)
                if isinstance(size, int) and size > 0:
                    backup_bytes += size

            status['backups_bytes'] = backup_bytes

            # When storage-wide quota is unavailable, at least show known backup consumption.
            if status.get('used_bytes') is None and backup_bytes > 0:
                status['used_bytes'] = backup_bytes
                if status.get('source') == 'unknown':
                    status['source'] = 'backup-files'
        except Exception as e:
            self._log(f"BackupManager: Error getting remote storage status: {str(e)}", xbmc.LOGWARNING)
        finally:
            try:
                self.disconnect_remote()
            except Exception:
                pass

        return status
    
    def delete_remote_file(self, filename):
        """Delete a file from the remote location"""
        if self.location_type == 0:  # Local
            # Just delete the file from the backup directory
            os.remove(os.path.join(self.backup_dir, filename))
            return True
        
        try:
            if self.remote_type == 0:  # SMB
                # Use xbmcvfs to delete the file
                remote_path = self.get_remote_path(filename)
                return xbmcvfs.delete(remote_path)
                
            elif self.remote_type == 1:  # NFS
                # Delete the file from the mounted directory
                remote_path = self.get_remote_path(filename)
                os.remove(remote_path)
                return True
                
            elif self.remote_type == 2:  # FTP
                # Delete the file via FTP
                self.remote_connection.delete(filename)
                return True
                
            elif self.remote_type == 3:  # SFTP
                # Delete the file via SFTP
                self.remote_connection.remove(filename)
                return True
                
            elif self.remote_type == 4:  # WebDAV
                # Delete the file via WebDAV
                remote_url = self.get_remote_path(filename)
                response = self.remote_connection['session'].delete(remote_url)
                return response.status_code in [200, 204]
                
        except Exception as e:
            self._log(f"Error deleting file from remote location: {str(e)}", xbmc.LOGERROR)
            return False
    
    def get_next_backup_time(self):
        """Calculate the next backup time based on schedule settings"""
        return None
    
    def update_schedule_info(self):
        """Update the last and next backup time in settings"""
        pass
    
    def should_run_backup(self):
        """Check if it's time to run a scheduled backup"""
        return False
    
    def notify(self, message, detailed_info="", persistent=False, progress=False):
        """Show notification if enabled"""
        if not self.addon.getSettingBool('show_notifications'):
            return

        # Format the message
        if any(keyword in message.lower() for keyword in ['progress:', 'backing up', 'processed:', 'uploading', 'copying']):
            # For progress notifications, always show the detailed info
            display_message = f"{message} - {detailed_info}" if detailed_info else message
        elif self.addon.getSettingBool('detailed_notifications') and detailed_info:
            display_message = f"{message} - {detailed_info}"
        else:
            display_message = message

        # Handle progress dialog for backup/restore operations
        if progress:
            if not self.progress_dialog:
                self.progress_dialog = xbmcgui.DialogProgressBG()
                self.progress_dialog.create(self.addon.getAddonInfo("name"), display_message)
            else:
                self.progress_dialog.update(0, message=display_message)
            return

        # Get the addon icon path
        icon = xbmcvfs.translatePath(os.path.join(self.addon.getAddonInfo('path'), 'resources', 'icon.png'))

        # Show notification
        if persistent:
            xbmcgui.Dialog().notification(
                self.addon.getAddonInfo("name"),
                display_message,
                icon,
                0  # Time to display: 0 means persistent
            )
        else:
            xbmcgui.Dialog().notification(
                self.addon.getAddonInfo("name"),
                display_message,
                icon,
                5000  # Time to display in milliseconds
            )

    def close_progress(self):
        """Close the progress dialog if it exists"""
        if self.progress_dialog:
            self.progress_dialog.close()
            self.progress_dialog = None
            
    def sanitize_string_encoding(self, string_value):
        """Sanitize string to handle Unicode surrogates and encoding issues"""
        if not isinstance(string_value, str):
            try:
                string_value = str(string_value)
            except Exception:
                return "<invalid-encoding>"
        try:
            # Test if the string can be encoded to UTF-8 safely
            string_value.encode('utf-8', errors='strict')
            return string_value
        except (UnicodeEncodeError, UnicodeDecodeError):
            # Replace unencodable characters to guarantee safe UTF-8 strings.
            try:
                return string_value.encode('utf-8', errors='replace').decode('utf-8')
            except Exception:
                try:
                    return string_value.encode('ascii', errors='backslashreplace').decode('ascii', errors='ignore')
                except Exception:
                    return "<invalid-encoding>"
    
    def format_section_name(self, item_name):
        """Format section name for display"""
        item_name = self.sanitize_string_encoding(item_name)
        section_map = {
            'config': 'Configuration',
            'guisettings': 'GUI Settings',
            'advancedsettings': 'Advanced Settings',
            'sources': 'Sources',
            'keyboard': 'Keyboard',
            'addons': 'Add-ons',
            'addon_data': 'Add-on Data',
            'keymaps': 'Keymaps',
            'userdata': 'User Data'
        }
        # Handle repository items
        if item_name.startswith('repo_'):
            repo_name = item_name.replace('repo_', '')
            return f'Repository: {repo_name}'
        return section_map.get(item_name, item_name)
    
    def update_progress(self, percent, message, detailed_info="", section_name=""):
        """Update the progress dialog"""
        if self.progress_dialog:
            # Add section info if detailed notifications are enabled
            if section_name and self.addon.getSettingBool('detailed_notifications'):
                formatted_section = self.sanitize_string_encoding(self.format_section_name(section_name))
                display_message = f"{message} - {formatted_section}"
                if detailed_info:
                    display_message = f"{display_message}: {detailed_info}"
            else:
                display_message = f"{message} - {detailed_info}" if detailed_info else message
            self.progress_dialog.update(percent, message=display_message)

    def set_operation_summary(self, operation, success, details=None):
        """Store a structured summary for the latest backup/restore operation."""
        self.last_operation_summary = {
            'operation': operation,
            'success': bool(success),
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'details': details or {}
        }

    def show_last_operation_summary(self):
        """Show a large summary dialog for the latest operation."""
        if not self.last_operation_summary:
            return False

        summary = self.last_operation_summary
        details = summary.get('details', {})
        operation = summary.get('operation', 'operation').capitalize()
        status = 'Completed' if summary.get('success') else 'Failed'

        def colorize(text, color):
            return f"[COLOR {color}]{text}[/COLOR]"

        palette = {
            'title': 'FF4FC3F7',
            'ok': 'FF66BB6A',
            'fail': 'FFEF5350',
            'label': 'FF90CAF9',
            'section': 'FFFFD54F',
            'muted': 'FFB0BEC5',
        }

        def add_key_value(lines_list, label, value):
            if value is None:
                return
            wrapped = textwrap.wrap(
                str(value),
                width=90,
                break_long_words=False,
                break_on_hyphens=False,
            ) or [""]
            lines_list.append(f"{colorize(label, palette['label'])}: {wrapped[0]}")
            for continuation in wrapped[1:]:
                lines_list.append(f"{' ' * (len(label) + 2)}{continuation}")

        def add_wrapped_bullet(lines_list, value):
            wrapped = textwrap.wrap(
                str(value),
                width=96,
                break_long_words=False,
                break_on_hyphens=False,
            ) or [""]
            lines_list.append(f"* {wrapped[0]}")
            for continuation in wrapped[1:]:
                lines_list.append(f"  {continuation}")

        status_line = colorize(status, palette['ok'] if summary.get('success') else palette['fail'])

        lines = [
            colorize(f"{operation} Summary", palette['title']),
            colorize("=" * 60, palette['muted']),
            f"{colorize('Status', palette['label'])}: {status_line}",
            f"{colorize('Time', palette['label'])}: {summary.get('timestamp', 'Unknown')}",
            colorize("Use up/down to scroll", palette['muted']),
        ]

        add_key_value(lines, 'Backup Name', details.get('backup_name'))
        add_key_value(lines, 'Backup File', details.get('backup_file'))
        add_key_value(lines, 'Location', details.get('location'))
        add_key_value(lines, 'Total Size', details.get('total_size_formatted'))
        add_key_value(lines, 'Compressed Size', details.get('compressed_size_formatted'))
        if details.get('compression_saved') is not None:
            lines.append(f"{colorize('Compression Saved', palette['label'])}: {details.get('compression_saved'):.1f}%")
        if details.get('total_files') is not None:
            lines.append(f"{colorize('Total Files', palette['label'])}: {details.get('total_files')}")
        if details.get('restored_files') is not None:
            lines.append(f"{colorize('Restored Files', palette['label'])}: {details.get('restored_files')}")
        if details.get('skipped_files') is not None:
            lines.append(f"{colorize('Skipped Files', palette['label'])}: {details.get('skipped_files')}")

        sections = details.get('sections') or {}
        if sections:
            lines.append("")
            lines.append(colorize("Sections", palette['section']))
            lines.append(colorize("-" * 60, palette['muted']))
            for section_name in sorted(sections.keys()):
                section_info = sections.get(section_name, {})
                file_count = section_info.get('files', 0)
                byte_count = section_info.get('bytes', 0)
                section_label = self.format_section_name(section_name)
                add_wrapped_bullet(lines, f"{section_label}: {file_count} files ({self.format_size(byte_count)})")

        skipped_examples = details.get('skipped_examples') or []
        if skipped_examples:
            lines.append("")
            lines.append(colorize("Skipped File Examples", palette['section']))
            lines.append(colorize("-" * 60, palette['muted']))
            for item in skipped_examples:
                add_wrapped_bullet(lines, item)

        if details.get('message'):
            lines.append("")
            lines.append(colorize("Notes", palette['section']))
            lines.append(colorize("-" * 60, palette['muted']))
            add_wrapped_bullet(lines, details.get('message'))

        title = f"{self.addon.getAddonInfo('name')} - {operation} Summary"
        summary_text = "\n".join(lines)

        # Prefer the custom message window so the summary matches addon UI style.
        try:
            popup_text(title, summary_text)
            return True
        except Exception:
            pass

        popup_message(title, summary_text)
        return True
    
    def format_size(self, size_bytes):
        """Format file size in bytes to human-readable format"""
        if size_bytes < 1024:
            return f"{size_bytes} B"
        elif size_bytes < 1024 * 1024:
            return f"{size_bytes/1024:.1f} KB"
        elif size_bytes < 1024 * 1024 * 1024:
            return f"{size_bytes/1024/1024:.1f} MB"
        else:
            return f"{size_bytes/1024/1024/1024:.2f} GB"

    def format_backup_date(self, backup_reference):
        """Return a human-readable backup date from filename or file metadata."""
        try:
            backup_name = os.path.basename(str(backup_reference))
            base_name = backup_name[:-4] if backup_name.lower().endswith('.zip') else backup_name

            # Preferred format: *_YYYYMMDD_HHMMSS
            match_split = re.search(r'(\d{8})_(\d{6})$', base_name)
            if match_split:
                timestamp = f"{match_split.group(1)}{match_split.group(2)}"
                return datetime.strptime(timestamp, '%Y%m%d%H%M%S').strftime('%Y-%m-%d %H:%M:%S')

            # Legacy format: *_YYYYMMDDHHMMSS
            match_full = re.search(r'(\d{14})$', base_name)
            if match_full:
                return datetime.strptime(match_full.group(1), '%Y%m%d%H%M%S').strftime('%Y-%m-%d %H:%M:%S')

            # Fallback to filesystem timestamp for local files
            if isinstance(backup_reference, str) and os.path.exists(backup_reference):
                return datetime.fromtimestamp(os.path.getmtime(backup_reference)).strftime('%Y-%m-%d %H:%M:%S')
        except Exception as e:
            self._log(f"Error parsing backup date for {backup_reference}: {str(e)}", xbmc.LOGWARNING)

        return "Unknown date"
    
    def get_repository_paths(self):
        """Get all repository addon paths"""
        repo_paths = {}
        addons_dir = os.path.join(self.kodi_home, 'addons')
        if os.path.exists(addons_dir):
            for item in os.listdir(addons_dir):
                if item.startswith('repository.') and os.path.isdir(os.path.join(addons_dir, item)):
                    # Add the repository addon folder
                    repo_paths[f'repo_{item}'] = os.path.join(addons_dir, item)
                    # Add its addon data if it exists
                    addon_data_path = os.path.join(self.kodi_userdata, 'addon_data', item)
                    if os.path.exists(addon_data_path):
                        repo_paths[f'repo_data_{item}'] = addon_data_path
        return repo_paths

    def get_backup_paths(self):
        """Get paths for all backup items based on settings"""
        paths = {}
        
        # Log which backup items are selected
        self._log("Backup items selected:", xbmc.LOGINFO)
        self._log(f"Configs: {self.addon.getSettingBool('backup_configs')}", xbmc.LOGINFO)
        self._log(f"Addons: {self.addon.getSettingBool('backup_addons')}", xbmc.LOGINFO)
        self._log(f"Repositories: {self.addon.getSettingBool('backup_repositories')}", xbmc.LOGINFO)
        self._log(f"Userdata: {self.addon.getSettingBool('backup_userdata')}", xbmc.LOGINFO)
        self._log(f"Sources: {self.addon.getSettingBool('backup_sources')}", xbmc.LOGINFO)
        
        # Configuration Files
        if self.addon.getSettingBool('backup_configs'):
            # Create temp directory if it doesn't exist
            if not self.temp_dir:
                self.temp_dir = os.path.join(xbmc.translatePath('special://temp'), 'libreelec_backupper')
                os.makedirs(self.temp_dir, exist_ok=True)
                self._temp_files.add(self.temp_dir)  # Track for cleanup

            # Handle config.txt specially - copy to temp location first
            config_src = '/flash/config.txt'
            if os.path.exists(config_src):
                config_temp = os.path.join(self.temp_dir, 'config.txt')
                try:
                    shutil.copy2(config_src, config_temp)
                    self._temp_files.add(config_temp)  # Track for cleanup
                    paths['config'] = config_temp  # Use temp location for backup
                    self._log(f"Copied config.txt to temp location: {config_temp}", xbmc.LOGINFO)
                except Exception as e:
                    self._log(f"Failed to copy config.txt: {str(e)}", xbmc.LOGERROR)

            # Add other config files
            config_paths = {
                'guisettings': os.path.join(self.kodi_userdata, 'guisettings.xml'),
                'advancedsettings': os.path.join(self.kodi_userdata, 'advancedsettings.xml'),
                'keyboard': os.path.join(self.kodi_userdata, 'keyboard.xml'),
                'keymaps': os.path.join(self.kodi_userdata, 'keymaps')
            }
            # Only add paths that exist
            for key, path in config_paths.items():
                if os.path.exists(path):
                    paths[key] = path
            self._log(f"Added config paths: {list(paths.keys())}", xbmc.LOGINFO)
        
        # Sources
        if self.addon.getSettingBool('backup_sources'):
            sources_path = os.path.join(self.kodi_userdata, 'sources.xml')
            if os.path.exists(sources_path):
                paths['sources'] = sources_path
                self._log("Added sources path", xbmc.LOGINFO)
        
        # Addons
        if self.addon.getSettingBool('backup_addons'):
            addons_path = os.path.join(self.kodi_home, 'addons')
            if os.path.exists(addons_path):
                paths['addons'] = addons_path
                self._log("Added addons path", xbmc.LOGINFO)
        
        # Repositories
        if self.addon.getSettingBool('backup_repositories'):
            repo_paths = self.get_repository_paths()
            if repo_paths:
                paths.update(repo_paths)
                self._log(f"Added repository paths: {list(repo_paths.keys())}", xbmc.LOGINFO)
        
        # Addon User Data and Settings
        if self.addon.getSettingBool('backup_userdata'):
            addon_data_path = os.path.join(self.kodi_userdata, 'addon_data')
            if os.path.exists(addon_data_path):
                paths['addon_data'] = addon_data_path
                self._log("Added addon data path", xbmc.LOGINFO)
        
        self._log(f"Final backup paths: {list(paths.keys())}", xbmc.LOGINFO)
        return paths
    
    def cleanup_resources(self):
        """Clean up resources before addon shutdown"""
        self.close_progress()
        try:
            # Close WebDAV session if it exists
            if hasattr(self, '_webdav_session') and self._webdav_session is not None:
                try:
                    self._webdav_session.close()
                except Exception as e:
                    self._log(f"Error closing WebDAV session: {str(e)}", xbmc.LOGWARNING)
                finally:
                    self._webdav_session = None
                
            # Disconnect remote connection
            if hasattr(self, 'remote_connection') and self.remote_connection is not None:
                try:
                    self.disconnect_remote()
                except Exception as e:
                    self._log(f"Error disconnecting remote: {str(e)}", xbmc.LOGWARNING)
            
            # Clean up temporary files
            if hasattr(self, '_temp_files'):
                for temp_file in self._temp_files:
                    try:
                        if os.path.exists(temp_file):
                            if os.path.isdir(temp_file):
                                shutil.rmtree(temp_file, ignore_errors=True)
                            else:
                                os.remove(temp_file)
                    except Exception as e:
                        self._log(f"Error removing temp file {temp_file}: {str(e)}", xbmc.LOGWARNING)
            
            self._temp_files.clear()
            
            # Force garbage collection
            gc.collect()
            
        except Exception as e:
            self._log(f"Error during resource cleanup: {str(e)}", xbmc.LOGERROR)

    def _cleanup_old_temp_files(self):
        """Clean up any old temporary files from previous sessions"""
        try:
            temp_dir = os.path.join(xbmcvfs.translatePath('special://temp'), 'libreelec_backupper')
            if os.path.exists(temp_dir):
                for item in os.listdir(temp_dir):
                    item_path = os.path.join(temp_dir, item)
                    try:
                        # Skip JSON files that contain remote backup information
                        if item.endswith('.json') and 'remote_backup_' in item:
                            self._log(f"Preserving remote backup info file: {item}", xbmc.LOGINFO)
                            continue
                            
                        if os.path.isfile(item_path):
                            os.unlink(item_path)
                        elif os.path.isdir(item_path):
                            shutil.rmtree(item_path)
                    except Exception as e:
                        self._log(f"Error cleaning up old temp file {item}: {str(e)}", xbmc.LOGWARNING)
        except Exception as e:
            self._log(f"Error in cleanup_old_temp_files: {str(e)}", xbmc.LOGWARNING)

    def cleanup_current_session(self):
        """Clean up temporary files from current session"""
        try:
            if hasattr(self, 'temp_dir') and self.temp_dir and os.path.exists(self.temp_dir):
                # Don't delete JSON files containing remote backup information
                for item in os.listdir(self.temp_dir):
                    item_path = os.path.join(self.temp_dir, item)
                    if item.endswith('.json') and 'remote_backup_' in item:
                        self._log(f"Preserving remote backup info file: {item}", xbmc.LOGINFO)
                        continue
                    try:
                        if os.path.isfile(item_path):
                            os.unlink(item_path)
                        elif os.path.isdir(item_path):
                            shutil.rmtree(item_path)
                    except Exception as e:
                        self._log(f"Error removing temp file {item}: {str(e)}", xbmc.LOGWARNING)
                self._log("Cleaned up current session temporary directory", xbmc.LOGINFO)
        except Exception as e:
            self._log(f"Error in cleanup_current_session: {str(e)}", xbmc.LOGWARNING)

    def __del__(self):
        """Cleanup when object is destroyed"""
        self.close_progress()
        self.cleanup_resources()

    def buffered_copy(self, source, dest, file_size, processed_size, total_size):
        """Copy file with progress tracking"""
        CHUNK_SIZE = 8192  # 8KB chunks
        bytes_copied = 0
        last_update = time.time()
        update_interval = 0.5  # Update every 0.5 seconds
        self._log(f"BackupManager: buffered_copy source={source} dest={dest} size={self.format_size(file_size)}", xbmc.LOGINFO)
        
        with open(source, 'rb') as src, open(dest, 'wb') as dst:
            while True:
                chunk = src.read(CHUNK_SIZE)
                if not chunk:
                    break
                
                dst.write(chunk)
                bytes_copied += len(chunk)
                current_time = time.time()
                
                # Update progress at intervals
                if current_time - last_update >= update_interval:
                    # Calculate percentages
                    file_percent = int((bytes_copied / file_size) * 100)
                    total_percent = int(((processed_size + bytes_copied) / total_size) * 100)
                    
                    # Format sizes
                    current_size = self.format_size(processed_size + bytes_copied)
                    total_size_str = self.format_size(total_size)
                    
                    # Update progress
                    self.update_progress(
                        total_percent,
                        f"Copying files... ({current_size} / {total_size_str})",
                        f"{file_percent}% of current file"
                    )
                    
                    # Show notification
                    self.notify(
                        "Copying files...",
                        f"{current_size} / {total_size_str}",
                        persistent=True
                    )
                    
                    last_update = current_time
        
        self._log(f"BackupManager: buffered_copy complete bytes={bytes_copied}", xbmc.LOGINFO)
        return bytes_copied

    def create_backup(self, backup_name=None):
        """Create a backup of the selected items"""
        try:
            self._refresh_logging_flag()
            self.log_verbose(
                "create_backup:start",
                backup_name=backup_name,
                location_type=self.location_type,
                backup_dir=self.backup_dir,
                remote_type=getattr(self, "remote_type", None),
                remote_path=getattr(self, "remote_path", None),
                remote_username=getattr(self, "remote_username", None),
                remote_password_set=bool(getattr(self, "remote_password", "")),
                remote_port=getattr(self, "remote_port", None),
            )
            # Notify backup start
            backup_type = "scheduled" if backup_name else "manual"
            self._log(f"BackupManager: create_backup type={backup_type} location_type={self.location_type}", xbmc.LOGINFO)
            self.email_notifier.notify_backup_started(backup_type)
            
            # Show initial progress
            self.notify("Starting backup process...", progress=True)
            
            # Clean up any old temporary files first
            self._cleanup_old_temp_files()
            
            # Create a new temporary directory for this session
            self.temp_dir = os.path.join(xbmcvfs.translatePath('special://temp'), 'libreelec_backupper', str(int(time.time())))
            os.makedirs(self.temp_dir, exist_ok=True)
            
            # Update backup location in case it changed
            self.update_backup_location()
            
            # Connect to remote location if needed
            if self.location_type != 0:  # Remote
                self.notify("Connecting to remote location...", persistent=True)
                if not self.connect_remote():
                    self.notify("Backup failed", "Failed to connect to remote location", persistent=True)
                    self.close_progress()
                    self.set_operation_summary('backup', False, {
                        'message': 'Failed to connect to remote location'
                    })
                    return False, "Failed to connect to remote location"
            
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            
            # Get paths to backup
            self.notify("Gathering files to backup...", persistent=True)
            paths = self.get_backup_paths()
            self._log(f"BackupManager: Paths to backup resolved {list(paths.keys())}", xbmc.LOGINFO)
            
            # Log the paths that will be backed up
            self._log(f"BackupManager: Paths to backup: {paths}", xbmc.LOGDEBUG)
            self.log_verbose("create_backup:paths", paths=list(paths.keys()))
            
            # Don't create empty backups
            if not paths:
                self.notify("Backup failed", "No items selected for backup", persistent=True)
                self.close_progress()
                self.set_operation_summary('backup', False, {
                    'message': 'No items selected for backup'
                })
                return False, "No items selected for backup"
            
            # Create backup name with included items
            backup_items = []
            if self.addon.getSettingBool('backup_configs'):
                backup_items.append('conf')
            if self.addon.getSettingBool('backup_addons'):
                backup_items.append('addons')
            if self.addon.getSettingBool('backup_repositories'):
                backup_items.append('repos')
            if self.addon.getSettingBool('backup_userdata'):
                backup_items.append('userdata')
            if self.addon.getSettingBool('backup_sources'):
                backup_items.append('src')
            
            # Add items to backup name
            items_str = '-'.join(backup_items) if backup_items else 'empty'
            backup_name = f'backup_{items_str}_{timestamp}'
            self._log(f"BackupManager: Backup name {backup_name}", xbmc.LOGINFO)
            
            # Create backup path in temp directory
            backup_path = os.path.join(self.temp_dir, f'{backup_name}.zip')
            self._temp_files.add(backup_path)  # Track for cleanup
            self._temp_files.add(self.temp_dir)  # Track temp directory for cleanup
            
            # Initialize progress dialog for backup operation
            self.notify("Starting backup process...", progress=True)
            
            try:
                # Calculate total size and collect files to backup
                total_size = 0
                files_to_backup = []
                processed_size = 0  # Track processed size
                
                # Process each path based on its type
                for item_name, path in paths.items():
                    self._log(f"Processing backup item: {item_name} at path: {path}", xbmc.LOGINFO)
                    
                    if not os.path.exists(path):
                        self._log(f"Path does not exist: {path}", xbmc.LOGWARNING)
                        continue
                        
                    if os.path.isfile(path):
                        if not os.path.islink(path):  # Skip symbolic links
                            try:
                                file_size = os.path.getsize(path)
                                total_size += file_size
                                
                                # Determine the appropriate archive name for configuration files
                                if item_name == 'config':
                                    arcname = 'flash/config.txt'  # Ensure config.txt goes to flash directory
                                elif item_name == 'sources':
                                    arcname = 'userdata/sources.xml'
                                elif item_name == 'guisettings':
                                    arcname = 'userdata/guisettings.xml'
                                elif item_name == 'advancedsettings':
                                    arcname = 'userdata/advancedsettings.xml'
                                elif item_name == 'keyboard':
                                    arcname = 'userdata/keyboard.xml'
                                else:
                                    arcname = item_name
                                arcname = self.sanitize_string_encoding(arcname)
                                    
                                files_to_backup.append((path, arcname, file_size, item_name))
                                self._log(f"Added file to backup: {path} as {arcname} ({self.format_size(file_size)})", xbmc.LOGINFO)
                            except OSError as e:
                                self._log(f"Error getting size for {path}: {str(e)}", xbmc.LOGWARNING)
                                continue
                    else:  # Directory
                        for root, dirs, files in os.walk(path):
                            for file in files:
                                file_path = os.path.join(root, file)
                                if not os.path.islink(file_path):  # Skip symbolic links
                                    try:
                                        file_size = os.path.getsize(file_path)
                                        total_size += file_size
                                        
                                        # Determine relative path based on directory type
                                        if item_name == 'addons':
                                            rel_path = os.path.relpath(file_path, os.path.dirname(path))
                                            arcname = rel_path
                                        elif item_name == 'addon_data':
                                            rel_path = os.path.relpath(file_path, os.path.dirname(path))
                                            arcname = f"userdata/{rel_path}"
                                        elif item_name == 'keymaps':
                                            rel_path = os.path.relpath(file_path, path)
                                            arcname = f"userdata/keymaps/{rel_path}"
                                        elif item_name.startswith('repo_'):
                                            rel_path = os.path.relpath(file_path, os.path.dirname(path))
                                            arcname = f"repo/{rel_path}"
                                        else:
                                            rel_path = os.path.relpath(file_path, path)
                                            arcname = f"{item_name}/{rel_path}"
                                        arcname = self.sanitize_string_encoding(arcname)
                                        
                                        files_to_backup.append((file_path, arcname, file_size, item_name))
                                    except OSError as e:
                                        self._log(f"Error getting size for {file_path}: {str(e)}", xbmc.LOGWARNING)
                                        continue
                
                self._log(f"BackupManager: Total files to backup {len(files_to_backup)}", xbmc.LOGINFO)
                total_size_formatted = self.format_size(total_size)
                self.notify("Starting backup", f"Total size: {total_size_formatted}")
                self._log(f"BackupManager: Total backup size {total_size_formatted} ({total_size} bytes)", xbmc.LOGINFO)

                section_stats = {}
                for _, _, entry_size, entry_section in files_to_backup:
                    section_bucket = section_stats.setdefault(entry_section, {'files': 0, 'bytes': 0})
                    section_bucket['files'] += 1
                    section_bucket['bytes'] += entry_size
                
                # Create manifest with sanitized paths (handle Unicode surrogates)
                sanitized_paths = {}
                for key, value in paths.items():
                    try:
                        # Test if the path can be encoded to JSON
                        # If it contains surrogates, encode/decode with error handling
                        value.encode('utf-8', errors='strict')
                        sanitized_paths[self.sanitize_string_encoding(key)] = value
                    except (UnicodeEncodeError, UnicodeDecodeError):
                        # Path contains problematic characters, encode with surrogateescape
                        try:
                            sanitized = value.encode('utf-8', errors='surrogateescape').decode('utf-8', errors='replace')
                            sanitized_paths[self.sanitize_string_encoding(key)] = sanitized
                        except Exception:
                            # Last resort: use a safe representation
                            safe_key = self.sanitize_string_encoding(key)
                            sanitized_paths[safe_key] = f"<path with encoding issues: {safe_key}>"
                
                manifest = {
                    'timestamp': timestamp,
                    'items': [self.sanitize_string_encoding(k) for k in paths.keys()],
                    'paths': sanitized_paths,
                    'backed_up_files': [],
                    'total_size': total_size,
                    'total_size_formatted': total_size_formatted
                }
                
                # Set compression settings based on addon settings
                compression_level = self.addon.getSettingInt('compression_level')
                # Map compression settings to actual ZIP compression levels
                compression_mapping = {
                    0: (zipfile.ZIP_STORED, 0),    # None
                    1: (zipfile.ZIP_DEFLATED, 1),  # Fast
                    2: (zipfile.ZIP_DEFLATED, 6),  # Normal
                    3: (zipfile.ZIP_DEFLATED, 9)   # Maximum
                }
                compression_method, compression_strength = compression_mapping.get(compression_level, (zipfile.ZIP_DEFLATED, 6))
                
                # Create ZIP file with selected compression
                with zipfile.ZipFile(backup_path, 'w', compression=compression_method, compresslevel=compression_strength, allowZip64=True) as zipf:
                    # Process each file
                    last_update_time = time.time()
                    update_interval = 0.5  # Update progress every 0.5 seconds
                    batch_size = 0  # Track size of current batch
                    self._log(f"BackupManager: ZIP compression method={compression_method} level={compression_strength}", xbmc.LOGINFO)
                    
                    for file_path, arcname, file_size, section_name in files_to_backup:
                        try:
                            safe_arcname = self.sanitize_string_encoding(arcname)
                            self._log(f"BackupManager: Adding to zip {file_path} -> {safe_arcname} size={self.format_size(file_size)} section={section_name}", xbmc.LOGDEBUG)
                            # Read and write directly to zip
                            with open(file_path, 'rb') as source:
                                # Create a ZipInfo object for more control
                                info = zipfile.ZipInfo(safe_arcname)
                                info.file_size = file_size
                                info.compress_type = compression_method
                                
                                # Open entry in zip file
                                with zipf.open(info, mode='w') as dest:
                                    # Copy with batched progress updates
                                    buffer_size = 1024 * 1024  # 1MB buffer
                                    bytes_copied = 0
                                    
                                    while True:
                                        chunk = source.read(buffer_size)
                                        if not chunk:
                                            break
                                        
                                        dest.write(chunk)
                                        bytes_copied += len(chunk)
                                        processed_size += len(chunk)
                                        batch_size += len(chunk)
                                        
                                        # Update progress based on time interval
                                        current_time = time.time()
                                        if current_time - last_update_time >= update_interval:
                                            progress = int((processed_size / total_size) * 100) if total_size > 0 else 0
                                            processed_formatted = self.format_size(processed_size)
                                            total_formatted = self.format_size(total_size)
                                            
                                            # Update progress dialog with section info
                                            self.update_progress(progress, "Backing up files", f"{processed_formatted} / {total_formatted}", section_name)
                                            self._log(f"BackupManager: Zip progress {progress}% processed={processed_formatted}/{total_formatted}", xbmc.LOGDEBUG)
                                            last_update_time = current_time
                                            batch_size = 0  # Reset batch size
                        
                            manifest['backed_up_files'].append(safe_arcname)
                            
                        except Exception as e:
                            self._log(f"Error backing up file {file_path}: {str(e)}", xbmc.LOGERROR)
                    
                    # Show final progress
                    progress = int((processed_size / total_size) * 100) if total_size > 0 else 0
                    processed_formatted = self.format_size(processed_size)
                    total_formatted = self.format_size(total_size)
                    self.update_progress(progress, "Backing up files", f"{processed_formatted} / {total_formatted}", section_name if 'section_name' in locals() else "")
                    self._log(f"BackupManager: Final zip progress {progress}% size={processed_formatted}/{total_formatted}", xbmc.LOGINFO)
                    
                    # Add manifest file with final encoding safety check
                    try:
                        # Final safety check: ensure all strings in manifest are JSON-safe
                        manifest_json = json.dumps(manifest, indent=4, default=str)
                    except (UnicodeEncodeError, ValueError) as e:
                        # If JSON encoding fails, sanitize all strings in manifest
                        safe_manifest = {
                            'timestamp': self.sanitize_string_encoding(manifest.get('timestamp', '')),
                            'items': [self.sanitize_string_encoding(item) for item in manifest.get('items', [])],
                            'paths': {k: self.sanitize_string_encoding(v) for k, v in manifest.get('paths', {}).items()},
                            'backed_up_files': [self.sanitize_string_encoding(f) for f in manifest.get('backed_up_files', [])],
                            'total_size': manifest.get('total_size', 0),
                            'total_size_formatted': self.sanitize_string_encoding(manifest.get('total_size_formatted', ''))
                        }
                        manifest_json = json.dumps(safe_manifest, indent=4, default=str)
                        self._log(f"BackupManager: Manifest encoding safety fallback applied due to: {str(e)}", xbmc.LOGWARNING)
                    
                    zipf.writestr('manifest.json', manifest_json)
                
                # Show completion notification
                self.close_progress()
                self.notify("Backup completed", f"Total size: {total_size_formatted}")
                
                # Get final backup size
                final_size = os.path.getsize(backup_path)
                final_size_formatted = self.format_size(final_size)
                compression_ratio = (1 - (final_size / total_size)) * 100 if total_size > 0 else 0
                size_info = f"Original: {total_size_formatted}, Compressed: {final_size_formatted} ({compression_ratio:.1f}% saved)"
                self._log(f"BackupManager: Zip complete {size_info}", xbmc.LOGINFO)
                
                # Upload to remote location if needed
                if self.location_type != 0:  # Remote
                    # Initialize progress dialog for upload
                    self.notify("Uploading backup...", size_info, progress=True)
                    upload_target = f'{backup_name}.zip'
                    self._log(f"BackupManager: Uploading {backup_path} -> {upload_target}", xbmc.LOGINFO)
                    if not self.upload_file(backup_path, upload_target):
                        self.notify("Backup failed", "Failed to upload to remote location", persistent=True)
                        self.close_progress()
                        self.disconnect_remote()
                        self.set_operation_summary('backup', False, {
                            'backup_name': f'{backup_name}.zip',
                            'location': self.remote_path,
                            'total_files': len(files_to_backup),
                            'total_size_formatted': total_size_formatted,
                            'message': 'Failed to upload backup to remote location'
                        })
                        return False, "Failed to upload backup to remote location"
                else:  # Local
                    # Move the backup file to the final location
                    final_path = os.path.join(self.backup_dir, f'{backup_name}.zip')
                    shutil.move(backup_path, final_path)
                    self._temp_files.remove(backup_path)  # Remove from cleanup tracking
                
                # Close progress dialog before showing final notification
                self.close_progress()
                
                # Cleanup old backups
                self.cleanup_old_backups(int(self.addon.getSetting('max_backups')))
                
                # Disconnect from remote location if needed
                if self.location_type != 0:  # Remote
                    self.disconnect_remote()
                
                # Show completion notification with persistent notification
                self.notify("Backup completed successfully", size_info, True)
                self._log(f"Backup completed: {size_info}", xbmc.LOGINFO)

                backup_target_name = f'{backup_name}.zip'
                backup_target_path = final_path if self.location_type == 0 else backup_target_name
                backup_location = self.backup_dir if self.location_type == 0 else self.remote_path
                self.set_operation_summary('backup', True, {
                    'backup_name': backup_target_name,
                    'backup_file': backup_target_path,
                    'location': backup_location,
                    'total_files': len(files_to_backup),
                    'total_size_formatted': total_size_formatted,
                    'compressed_size_formatted': final_size_formatted,
                    'compression_saved': compression_ratio,
                    'sections': section_stats,
                    'message': size_info,
                })
                
                # On success, notify completion with backup info
                backup_info = {
                    'name': backup_name or os.path.basename(final_path),
                    'size': size_info,
                    'location': self.backup_dir if self.location_type == 0 else f"{self.remote_path} ({['SMB', 'NFS', 'FTP', 'SFTP', 'WebDAV'][self.remote_type]})",
                    'items': ', '.join(backup_items)
                }
                self.email_notifier.notify_backup_complete(backup_type, backup_info)
                
                return True, f"Backup completed successfully. {size_info}"
                
            except Exception as e:
                error_msg = self.sanitize_string_encoding(f"Error creating backup: {str(e)}")
                self.close_progress()
                self.notify("Backup failed", error_msg, persistent=True)
                self.set_operation_summary('backup', False, {
                    'message': error_msg,
                    'total_files': len(files_to_backup) if 'files_to_backup' in locals() else 0,
                    'total_size_formatted': total_size_formatted if 'total_size_formatted' in locals() else '',
                })
                
                # Notify backup failure
                self.email_notifier.notify_backup_failed(backup_type, error_msg)
                
                if self.location_type != 0:  # Remote
                    self.disconnect_remote()
                return False, error_msg
                
        except Exception as e:
            error_msg = self.sanitize_string_encoding(f"Error in create_backup: {str(e)}")
            self.close_progress()
            self.notify("Backup failed", error_msg, persistent=True)
            self.set_operation_summary('backup', False, {
                'message': error_msg
            })
            
            # Notify backup failure
            self.email_notifier.notify_backup_failed(backup_type, error_msg)
            
            if self.location_type != 0:  # Remote
                self.disconnect_remote()
            return False, error_msg
        finally:
            # Clean up resources and temporary files only after everything is done
            try:
                self.cleanup_current_session()
                self.cleanup_resources()
            except Exception as e:
                self._log(f"Error during final cleanup: {str(e)}", xbmc.LOGERROR)
    
    def get_all_backups(self):
        """Get list of all available backup files"""
        self.log_verbose("get_all_backups:start", location_type=self.location_type, backup_dir=self.backup_dir)
        self.update_backup_location()

        self._log(f"BackupManager: get_all_backups location_type={self.location_type} dir={self.backup_dir}", xbmc.LOGINFO)

        if self.location_type == 0:  # Local
            backup_patterns = [
                os.path.join(self.backup_dir, 'backup_*.zip'),
                os.path.join(self.backup_dir, 'libreelec_backup_*.zip'),
            ]
            backups = []
            for pattern in backup_patterns:
                backups.extend(glob.glob(pattern))
            backups = list(set(backups))
            # Newest first for better UX in restore dialogs and status display.
            return sorted(backups, key=lambda p: os.path.getmtime(p), reverse=True)
        else:  # Remote
            try:
                # Connect to remote location
                if not self.connect_remote():
                    self._log("Failed to connect to remote location for listing backups", xbmc.LOGERROR)
                    return []

                # List files based on remote type
                files = self.list_remote_files()

                # Filter for backup files (new and legacy naming patterns)
                backup_files = [
                    f for f in files
                    if f.endswith('.zip') and (f.startswith('backup_') or f.startswith('libreelec_backup_'))
                ]

                # Sort by modification time (newest first) if possible
                try:
                    backup_files_with_time = []
                    for f in backup_files:
                        # Get file info if available
                        try:
                            if self.remote_type == 0:  # SMB
                                # For SMB, we can't easily get timestamps via xbmcvfs
                                backup_files_with_time.append((f, 0))
                            elif self.remote_type == 1:  # NFS
                                stat = os.stat(os.path.join(self.remote_connection, f))
                                backup_files_with_time.append((f, stat.st_mtime))
                            elif self.remote_type == 2:  # FTP
                                # FTP doesn't provide easy timestamp access
                                backup_files_with_time.append((f, 0))
                            elif self.remote_type == 3:  # SFTP
                                stat = self.remote_connection.stat(f)
                                backup_files_with_time.append((f, stat.st_mtime))
                            elif self.remote_type == 4:  # WebDAV
                                # WebDAV timestamps are complex, use 0
                                backup_files_with_time.append((f, 0))
                        except:
                            backup_files_with_time.append((f, 0))

                    # Sort by timestamp (newest first)
                    backup_files_with_time.sort(key=lambda x: x[1], reverse=True)
                    backup_files = [f[0] for f in backup_files_with_time]
                except Exception as e:
                    xbmc.log(f"Error sorting backup files by time: {str(e)}", xbmc.LOGWARNING)
                    # Fall back to alphabetical sorting
                    backup_files.sort(reverse=True)

                self._log(f"Found {len(backup_files)} backup files: {backup_files}", xbmc.LOGINFO)
                return backup_files

            except Exception as e:
                self._log(f"Error getting remote backups: {str(e)}", xbmc.LOGERROR)
                import traceback
                self._log(f"Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
                return []
            finally:
                # Disconnect from remote location
                self.disconnect_remote()
    
    def show_rotation_warning(self):
        """Show warning dialog when enabling backup rotation"""
        confirmed = popup_confirm(
            "Warning",
            "Backup rotation will automatically delete old backups when enabled.\n\nAre you sure you want to continue?",
            yes_label="Yes, Enable",
            no_label="No, Disable"
        )
        
        if not confirmed:
            # User chose to disable rotation
            self.addon.setSetting('enable_rotation', 'false')
            xbmc.log("User disabled backup rotation after warning", xbmc.LOGINFO)
            self.notify(
                "Backup Cleanup",
                "Backup rotation has been disabled"
            )
            return False
        return True

    def cleanup_old_backups(self, max_backups):
        """Clean up old backups based on rotation strategy"""
        try:
            # Check if backup rotation is enabled
            if not self.addon.getSettingBool('enable_rotation'):
                xbmc.log("Backup rotation is disabled", xbmc.LOGINFO)
                self.notify(
                    "Backup Cleanup",
                    "Backup rotation is disabled"
                )
                return

            # Get all backup files
            backup_files = []
            
            # For remote locations, ensure we have a connection
            if self.location_type != 0:  # Remote
                if not self.connect_remote():
                    xbmc.log("Failed to connect to remote location for cleanup", xbmc.LOGERROR)
                    self.notify(
                        "Backup Cleanup Error",
                        "Failed to connect to remote location"
                    )
                    return
                
            # List backup files
            if self.location_type == 0:  # Local
                for file in os.listdir(self.backup_dir):
                    if file.endswith('.zip'):
                        file_path = os.path.join(self.backup_dir, file)
                        backup_files.append((file_path, os.path.getmtime(file_path)))
            else:  # Remote
                if self.remote_type == 0:  # SMB
                    for file in os.listdir(self.backup_dir):
                        if file.endswith('.zip'):
                            file_path = os.path.join(self.backup_dir, file)
                            backup_files.append((file_path, os.path.getmtime(file_path)))
                elif self.remote_type == 1:  # NFS
                    for file in os.listdir(self.backup_dir):
                        if file.endswith('.zip'):
                            file_path = os.path.join(self.backup_dir, file)
                            backup_files.append((file_path, os.path.getmtime(file_path)))
                elif self.remote_type == 2:  # FTP
                    for file in self.ftp.nlst():
                        if file.endswith('.zip'):
                            backup_files.append((file, self.ftp.voidcmd(f'MDTM {file}')[4:]))
                elif self.remote_type == 3:  # SFTP
                    for file in self.sftp.listdir():
                        if file.endswith('.zip'):
                            backup_files.append((file, self.sftp.stat(file).st_mtime))
                elif self.remote_type == 4:  # WebDAV
                    if self.remote_connection and 'session' in self.remote_connection:
                        response = self.remote_connection['session'].request(
                            'PROPFIND', 
                            self.remote_connection['base_url'], 
                            headers={'Depth': '1'}
                        )
                        
                        if response.status_code == 207:  # Multi-status
                            # Parse XML response to get file names
                            from xml.etree import ElementTree
                            root = ElementTree.fromstring(response.content)
                            ns = {'d': 'DAV:'}
                            
                            for response_elem in root.findall('.//d:response', ns):
                                href = response_elem.find('.//d:href', ns).text
                                filename = href.split('/')[-1] if href.split('/')[-1] else href.split('/')[-2]
                                filename = urllib.parse.unquote(filename)
                                
                                if filename.endswith('.zip'):
                                    # Get last modified time
                                    last_modified = response_elem.find('.//d:getlastmodified', ns)
                                    if last_modified is not None:
                                        try:
                                            from email.utils import parsedate_to_datetime
                                            last_modified_time = parsedate_to_datetime(last_modified.text).timestamp()
                                        except:
                                            last_modified_time = 0
                                    else:
                                        last_modified_time = 0
                                        
                                    # Store the full URL path for deletion
                                    file_url = self.remote_connection['base_url'].rstrip('/') + '/' + filename
                                    backup_files.append((file_url, last_modified_time))
                                    xbmc.log(f"Found backup file: {filename} with timestamp {last_modified_time}", xbmc.LOGINFO)
                    else:
                        xbmc.log("WebDAV connection not initialized", xbmc.LOGERROR)
                        self.notify(
                            "Backup Cleanup Error",
                            "WebDAV connection not initialized"
                        )
                        return

            # Log the found backup files
            xbmc.log(f"Found {len(backup_files)} backup files before sorting", xbmc.LOGINFO)
            for bf in backup_files:
                xbmc.log(f"Backup file: {bf[0]} with timestamp {bf[1]}", xbmc.LOGINFO)

            # Sort backups by modification time
            backup_files.sort(key=lambda x: x[1], reverse=True)

            # Get rotation strategy
            rotation_strategy = int(self.addon.getSetting('backup_rotation') or "0")
            strategy_names = ["Keep Newest", "Keep Oldest", "Keep Both Ends"]

            # Notify about current rotation strategy
            self.notify(
                "Backup Rotation",
                f"Strategy: {strategy_names[rotation_strategy]} (Max: {max_backups})"
            )

            # Determine which backups to keep
            if len(backup_files) > max_backups:
                if rotation_strategy == 0:  # Keep Newest
                    backups_to_keep = backup_files[:max_backups]
                    backups_to_delete = backup_files[max_backups:]
                elif rotation_strategy == 1:  # Keep Oldest
                    backups_to_keep = backup_files[-max_backups:]
                    backups_to_delete = backup_files[:-max_backups]
                else:  # Keep Both Ends
                    half = max_backups // 2
                    backups_to_keep = backup_files[:half] + backup_files[-half:]
                    backups_to_delete = backup_files[half:-half]

                # Delete old backups
                deleted_count = 0
                for file_path, _ in backups_to_delete:
                    try:
                        if self.location_type == 0:  # Local
                            os.remove(file_path)
                        else:  # Remote
                            if self.remote_type == 0:  # SMB
                                os.remove(file_path)
                            elif self.remote_type == 1:  # NFS
                                os.remove(file_path)
                            elif self.remote_type == 2:  # FTP
                                self.ftp.delete(file_path)
                            elif self.remote_type == 3:  # SFTP
                                self.sftp.remove(file_path)
                            elif self.remote_type == 4:  # WebDAV
                                if self.remote_connection and 'session' in self.remote_connection:
                                    response = self.remote_connection['session'].delete(file_path)
                                    if response.status_code not in [200, 204, 404]:
                                        xbmc.log(f"Error deleting WebDAV file {file_path}: {response.status_code}", xbmc.LOGERROR)
                                        continue
                                else:
                                    continue
                        xbmc.log(f"Deleted old backup: {file_path}", xbmc.LOGINFO)
                        deleted_count += 1
                    except Exception as e:
                        xbmc.log(f"Error deleting old backup {file_path}: {str(e)}", xbmc.LOGERROR)

                # Notify about cleanup results
                if deleted_count > 0:
                    self.notify(
                        "Backup Cleanup Complete",
                        f"Deleted {deleted_count} old backup{'s' if deleted_count > 1 else ''}\n"
                        f"Keeping {len(backups_to_keep)} backup{'s' if len(backups_to_keep) > 1 else ''}"
                    )
                else:
                    self.notify(
                        "Backup Cleanup",
                        "No backups needed to be deleted"
                    )
            else:
                self.notify(
                    "Backup Cleanup",
                    f"Current backup count ({len(backup_files)}) is within limit ({max_backups})"
                )

            # Always disconnect from remote location if we connected
            if self.location_type != 0:  # Remote
                self.disconnect_remote()

        except Exception as e:
            xbmc.log(f"Error during backup cleanup: {str(e)}", xbmc.LOGERROR)
            self.notify(
                "Backup Cleanup Error",
                f"Error during cleanup: {str(e)}"
            )
    
    def is_libreelec(self):
        """Check if running on LibreELEC system"""
        return os.path.exists('/flash')
    
    def mount_flash_rw(self):
        """Mount /flash in read-write mode (LibreELEC only)"""
        # Skip on non-LibreELEC systems
        if not self.is_libreelec():
            return True
        
        try:
            subprocess.run(['mount', '-o', 'remount,rw', '/flash'], check=True)
            return True
        except subprocess.CalledProcessError as e:
            xbmc.log(f"Error mounting /flash as read-write: {str(e)}", xbmc.LOGERROR)
            return False
    
    def mount_flash_ro(self):
        """Mount /flash back in read-only mode (LibreELEC only)"""
        # Skip on non-LibreELEC systems
        if not self.is_libreelec():
            return True
        
        try:
            subprocess.run(['mount', '-o', 'remount,ro', '/flash'], check=True)
            return True
        except subprocess.CalledProcessError as e:
            xbmc.log(f"Error mounting /flash as read-only: {str(e)}", xbmc.LOGERROR)
            return False
    
    def mount_userdata_rw(self):
        """Mount userdata directory in read-write mode"""
        # Get the actual mount point for userdata
        userdata_path = self.kodi_userdata
        
        # Check if userdata is already writable
        test_file = os.path.join(userdata_path, '.write_test')
        try:
            with open(test_file, 'w') as f:
                f.write('test')
            os.remove(test_file)
            xbmc.log("Userdata directory is already writable", xbmc.LOGINFO)
            return True
        except (IOError, PermissionError, OSError):
            xbmc.log("Userdata directory is not writable - checking if remount is possible", xbmc.LOGINFO)
        
        # Only attempt remount on LibreELEC
        if not self.is_libreelec():
            xbmc.log("Not on LibreELEC - skipping remount attempt", xbmc.LOGINFO)
            return True
        
        try:
            # Try to find and remount the mount point
            mount_info = subprocess.run(['mount'], capture_output=True, text=True, check=True)
            mount_lines = mount_info.stdout.splitlines()
            
            # Find longest matching mount point for specificity
            longest_mount = None
            for line in mount_lines:
                parts = line.split()
                if len(parts) >= 3:
                    mount_point = parts[2]
                    if userdata_path.startswith(mount_point):
                        if longest_mount is None or len(mount_point) > len(longest_mount):
                            longest_mount = mount_point
            
            if longest_mount and longest_mount != '/':
                xbmc.log(f"Mounting {longest_mount} as read-write", xbmc.LOGINFO)
                subprocess.run(['mount', '-o', 'remount,rw', longest_mount], check=True)
                
                # Verify it worked
                try:
                    with open(test_file, 'w') as f:
                        f.write('test')
                    os.remove(test_file)
                    xbmc.log("Userdata directory verified writable after remount", xbmc.LOGINFO)
                    return True
                except (IOError, PermissionError, OSError):
                    xbmc.log("Remount didn't help - proceeding anyway", xbmc.LOGWARNING)
                    return True
            else:
                xbmc.log("Could not find appropriate mount point for remount", xbmc.LOGINFO)
                return True
                
        except Exception as e:
            xbmc.log(f"Remount attempt failed: {str(e)} - proceeding anyway", xbmc.LOGWARNING)
            return True
            
    def mount_userdata_ro(self):
        """Mount userdata directory back in read-only mode"""
        # Skip on non-LibreELEC systems
        if not self.is_libreelec():
            return True
        
        try:
            userdata_path = self.kodi_userdata
            mount_info = subprocess.run(['mount'], capture_output=True, text=True, check=True)
            mount_lines = mount_info.stdout.splitlines()
            
            # Find longest matching mount point
            longest_mount = None
            for line in mount_lines:
                parts = line.split()
                if len(parts) >= 3:
                    mount_point = parts[2]
                    if userdata_path.startswith(mount_point):
                        if longest_mount is None or len(mount_point) > len(longest_mount):
                            longest_mount = mount_point
            
            if longest_mount and longest_mount != '/':
                subprocess.run(['mount', '-o', 'remount,ro', longest_mount], check=True)
                return True
            return True
                
        except Exception as e:
            xbmc.log(f"Error remounting userdata as read-only: {str(e)}", xbmc.LOGERROR)
            return False
    
    def mount_addons_rw(self):
        """Mount addons directory in read-write mode"""
        # Get the actual path for addons
        addons_path = os.path.join(self.kodi_home, 'addons')
        
        # Check if addons directory is already writable
        test_file = os.path.join(addons_path, '.write_test')
        try:
            os.makedirs(addons_path, exist_ok=True)
            with open(test_file, 'w') as f:
                f.write('test')
            os.remove(test_file)
            xbmc.log("Addons directory is already writable", xbmc.LOGINFO)
            return True
        except (IOError, PermissionError, OSError):
            xbmc.log("Addons directory is not writable - checking if remount is possible", xbmc.LOGINFO)
        
        # Only attempt remount on LibreELEC
        if not self.is_libreelec():
            xbmc.log("Not on LibreELEC - skipping remount attempt", xbmc.LOGINFO)
            return True
        
        try:
            # Try to find and remount the mount point
            mount_info = subprocess.run(['mount'], capture_output=True, text=True, check=True)
            mount_lines = mount_info.stdout.splitlines()
            
            # Find longest matching mount point for specificity
            longest_mount = None
            for line in mount_lines:
                parts = line.split()
                if len(parts) >= 3:
                    mount_point = parts[2]
                    if addons_path.startswith(mount_point):
                        if longest_mount is None or len(mount_point) > len(longest_mount):
                            longest_mount = mount_point
            
            if longest_mount and longest_mount != '/':
                xbmc.log(f"Mounting {longest_mount} as read-write", xbmc.LOGINFO)
                subprocess.run(['mount', '-o', 'remount,rw', longest_mount], check=True)
                
                # Verify it worked
                try:
                    os.makedirs(addons_path, exist_ok=True)
                    with open(test_file, 'w') as f:
                        f.write('test')
                    os.remove(test_file)
                    xbmc.log("Addons directory verified writable after remount", xbmc.LOGINFO)
                    return True
                except (IOError, PermissionError, OSError):
                    xbmc.log("Remount didn't help - proceeding anyway", xbmc.LOGWARNING)
                    return True
            else:
                xbmc.log("Could not find appropriate mount point for remount", xbmc.LOGINFO)
                return True
                
        except Exception as e:
            xbmc.log(f"Remount attempt failed: {str(e)} - proceeding anyway", xbmc.LOGWARNING)
            return True
            
    def mount_addons_ro(self):
        """Mount addons directory back in read-only mode"""
        # Skip on non-LibreELEC systems
        if not self.is_libreelec():
            return True
        
        try:
            addons_path = os.path.join(self.kodi_home, 'addons')
            mount_info = subprocess.run(['mount'], capture_output=True, text=True, check=True)
            mount_lines = mount_info.stdout.splitlines()
            
            # Find longest matching mount point
            longest_mount = None
            for line in mount_lines:
                parts = line.split()
                if len(parts) >= 3:
                    mount_point = parts[2]
                    if addons_path.startswith(mount_point):
                        if longest_mount is None or len(mount_point) > len(longest_mount):
                            longest_mount = mount_point
            
            if longest_mount and longest_mount != '/':
                subprocess.run(['mount', '-o', 'remount,ro', longest_mount], check=True)
                return True
            return True
                
        except Exception as e:
            xbmc.log(f"Error remounting addons as read-only: {str(e)}", xbmc.LOGERROR)
            return False
    
    def restore_file(self, zip_file, file_info, extract_path):
        """Restore a single file with special handling for config.txt, userdata, and addons"""
        try:
            # Handle configuration files that need /flash to be writable
            if extract_path == '/flash/config.txt' or extract_path.startswith('/flash/'):
                xbmc.log(f"Preparing to restore configuration file: {extract_path}", xbmc.LOGINFO)
                
                # Try to mount /flash in read-write mode (non-blocking)
                mount_success = self.mount_flash_rw()
                if mount_success:
                    xbmc.log("/flash mounted in read-write mode", xbmc.LOGINFO)
                else:
                    xbmc.log("Warning: Could not mount /flash as read-write, will try anyway", xbmc.LOGWARNING)
                
                restore_success = False
                
                try:
                    # Ensure directory exists
                    os.makedirs(os.path.dirname(extract_path), exist_ok=True)
                    
                    # Extract the file
                    with zip_file.open(file_info) as source, open(extract_path, 'wb') as target:
                        shutil.copyfileobj(source, target)
                    xbmc.log(f"Configuration file extracted successfully: {extract_path}", xbmc.LOGINFO)
                    
                    # Try to set permissions (may fail on read-only FS)
                    try:
                        os.chmod(extract_path, 0o644)
                        xbmc.log(f"File permissions set to 644: {extract_path}", xbmc.LOGINFO)
                    except (IOError, OSError) as perm_err:
                        xbmc.log(f"Could not set file permissions: {str(perm_err)}", xbmc.LOGWARNING)
                    
                    restore_success = True
                except Exception as e:
                    xbmc.log(f"Error during configuration file restore: {str(e)}", xbmc.LOGERROR)
                    raise e
                finally:
                    # Only try to remount as read-only if we successfully mounted it
                    if mount_success:
                        xbmc.log("Attempting to remount /flash as read-only", xbmc.LOGINFO)
                        if not self.mount_flash_ro():
                            error_msg = "Warning: Failed to remount /flash as read-only"
                            xbmc.log(error_msg, xbmc.LOGWARNING)
                            if restore_success:
                                self.notify(error_msg)
                        else:
                            xbmc.log("/flash remounted as read-only", xbmc.LOGINFO)
                    
                    if not restore_success:
                        return False, f"Failed to restore {os.path.basename(extract_path)}"
                
                return True, None
            
            # Handle userdata files
            elif extract_path.startswith(self.kodi_userdata):
                xbmc.log(f"Preparing to restore userdata file: {extract_path}", xbmc.LOGINFO)
                
                # Try to mount userdata in read-write mode (non-blocking)
                mount_success = self.mount_userdata_rw()
                if mount_success:
                    xbmc.log("Userdata mounted in read-write mode", xbmc.LOGINFO)
                else:
                    xbmc.log("Warning: Could not mount userdata as read-write, will try anyway", xbmc.LOGWARNING)
                
                restore_success = False
                
                try:
                    # Ensure the directory exists
                    os.makedirs(os.path.dirname(extract_path), exist_ok=True)
                    
                    # Extract the file
                    with zip_file.open(file_info) as source, open(extract_path, 'wb') as target:
                        shutil.copyfileobj(source, target)
                    
                    xbmc.log(f"File extracted successfully: {extract_path}", xbmc.LOGINFO)
                    
                    # Try to set permissions (may fail on read-only FS)
                    try:
                        if os.path.isdir(extract_path):
                            os.chmod(extract_path, 0o755)
                        else:
                            os.chmod(extract_path, 0o644)
                    except (IOError, OSError) as perm_err:
                        xbmc.log(f"Could not set file permissions: {str(perm_err)}", xbmc.LOGWARNING)
                    
                    restore_success = True
                except Exception as e:
                    xbmc.log(f"Error during userdata file restore: {str(e)}", xbmc.LOGERROR)
                    raise e
                finally:
                    # Only try to remount as read-only if we successfully mounted it
                    if mount_success:
                        xbmc.log("Attempting to remount userdata as read-only", xbmc.LOGINFO)
                        if not self.mount_userdata_ro():
                            error_msg = "Warning: Failed to remount userdata as read-only"
                            xbmc.log(error_msg, xbmc.LOGWARNING)
                            # If restore was successful but remount failed, still warn the user
                            if restore_success:
                                self.notify(error_msg)
                        else:
                            xbmc.log("Userdata remounted as read-only", xbmc.LOGINFO)
                    
                    if not restore_success:
                        return False, f"Failed to restore {os.path.basename(extract_path)}"
                
                return True, None
            
            # Handle addons files
            elif extract_path.startswith(os.path.join(self.kodi_home, 'addons')):
                xbmc.log(f"Preparing to restore addon file: {extract_path}", xbmc.LOGINFO)
                
                # Try to mount addons directory in read-write mode (non-blocking)
                mount_success = self.mount_addons_rw()
                if mount_success:
                    xbmc.log("Addons directory mounted in read-write mode", xbmc.LOGINFO)
                else:
                    xbmc.log("Warning: Could not mount addons directory as read-write, will try anyway", xbmc.LOGWARNING)
                
                restore_success = False
                
                try:
                    # Ensure the directory exists with proper permissions
                    parent_dir = os.path.dirname(extract_path)
                    os.makedirs(parent_dir, exist_ok=True)
                    
                    # Try to set write permissions on parent directory
                    try:
                        os.chmod(parent_dir, 0o755)
                    except (IOError, OSError):
                        pass
                    
                    # Extract the file
                    with zip_file.open(file_info) as source, open(extract_path, 'wb') as target:
                        shutil.copyfileobj(source, target)
                    
                    xbmc.log(f"Addon file extracted successfully: {extract_path}", xbmc.LOGINFO)
                    
                    # Try to set proper permissions
                    try:
                        if os.path.isdir(extract_path):
                            os.chmod(extract_path, 0o755)
                        else:
                            os.chmod(extract_path, 0o644)
                    except (IOError, OSError) as perm_err:
                        xbmc.log(f"Could not set file permissions: {str(perm_err)}", xbmc.LOGWARNING)
                    
                    restore_success = True
                except Exception as e:
                    xbmc.log(f"Error during addon file restore: {str(e)}", xbmc.LOGERROR)
                    raise e
                finally:
                    # Only try to remount as read-only if we successfully mounted it
                    if mount_success:
                        xbmc.log("Attempting to remount addons directory as read-only", xbmc.LOGINFO)
                        if not self.mount_addons_ro():
                            error_msg = "Warning: Failed to remount addons directory as read-only"
                            xbmc.log(error_msg, xbmc.LOGWARNING)
                            # If restore was successful but remount failed, still warn the user
                            if restore_success:
                                self.notify(error_msg)
                        else:
                            xbmc.log("Addons directory remounted as read-only", xbmc.LOGINFO)
                    
                    if not restore_success:
                        return False, f"Failed to restore {os.path.basename(extract_path)}"
                
                return True, None
            
            else:
                # Normal file extraction
                # Ensure the directory exists
                os.makedirs(os.path.dirname(extract_path), exist_ok=True)
                
                # Extract the file
                with zip_file.open(file_info) as source, open(extract_path, 'wb') as target:
                    shutil.copyfileobj(source, target)
                
                return True, None
                
        except Exception as e:
            return False, str(e)
    
    def restore_backup(self, backup_file=None):
        """Restore a backup from a file"""
        self.log_verbose(
            "restore_backup:start",
            backup_file=backup_file,
            location_type=self.location_type,
            backup_dir=self.backup_dir,
            remote_type=getattr(self, "remote_type", None),
            remote_path=getattr(self, "remote_path", None),
        )
        try:
            if backup_file is None:
                # Get list of available backups
                backups = self.get_all_backups()
                if not backups:
                    return False, "No backup files found"
                
                # Create backup options with detailed information
                backup_options = []
                for backup in backups:
                    try:
                        # Check if this is a remote backup placeholder
                        if isinstance(backup, str) and backup.endswith('.json'):
                            with open(backup, 'r') as f:
                                remote_info = json.load(f)
                                backup_name = remote_info.get('remote_file', 'Unknown backup')
                        else:
                            backup_name = os.path.basename(backup)
                        
                        # Get backup date
                        backup_date = self.format_backup_date(backup)
                        backup_size = os.path.getsize(backup) if os.path.exists(backup) else 0
                        backup_size_formatted = self.format_size(backup_size)
                        
                        # Create display string
                        display_name = f"{backup_date} - {backup_name} ({backup_size_formatted})"
                        
                        backup_options.append((display_name, backup))
                    except Exception as e:
                        xbmc.log(f"Error processing backup {backup}: {str(e)}", xbmc.LOGERROR)
                        continue
                
                if not backup_options:
                    return False, "No valid backup files found"
                
                # Show dialog to select backup
                dialog = xbmcgui.Dialog()
                selected = dialog.select("Select backup to restore", [opt[0] for opt in backup_options])
                
                if selected == -1:  # User cancelled
                    return False, "Backup restore cancelled"
                
                backup_file = backup_options[selected][1]
            
            # Clean up any old temporary files first
            self._cleanup_old_temp_files()
            
            # Create a new temporary directory for this session
            temp_base = xbmcvfs.translatePath('special://temp')
            self.temp_dir = os.path.join(temp_base, 'libreelec_backupper', str(int(time.time())))
            os.makedirs(self.temp_dir, exist_ok=True)
            xbmc.log(f"Created temporary directory: {self.temp_dir}", xbmc.LOGINFO)
            
            # Check if this is a remote backup placeholder
            is_remote = False
            remote_info = None
            try:
                if isinstance(backup_file, str) and backup_file.endswith('.json'):
                    # Ensure the JSON file exists
                    if not os.path.exists(backup_file):
                        xbmc.log(f"Remote backup info file not found: {backup_file}", xbmc.LOGERROR)
                        return False, f"Remote backup info file not found: {backup_file}"
                        
                    with open(backup_file, 'r') as f:
                        remote_info = json.load(f)
                        is_remote = True
                        
                        # Validate remote info
                        required_fields = ['remote_file', 'remote_path', 'remote_type']
                        missing_fields = [field for field in required_fields if field not in remote_info]
                        if missing_fields:
                            xbmc.log(f"Missing required fields in remote info: {missing_fields}", xbmc.LOGERROR)
                            return False, f"Invalid remote backup information: missing {', '.join(missing_fields)}"
                            
                        # Log remote info for debugging
                        xbmc.log(f"Remote backup info: {json.dumps(remote_info, indent=2)}", xbmc.LOGINFO)
            except (json.JSONDecodeError, IOError) as e:
                xbmc.log(f"Error reading remote info: {str(e)}", xbmc.LOGERROR)
                return False, f"Invalid remote backup information: {str(e)}"
            
            if is_remote and remote_info:
                # Download the remote backup first
                xbmc.log(f"Downloading remote backup: {remote_info.get('remote_file', 'Unknown')}", xbmc.LOGINFO)
                
                # Connect to remote location
                self.remote_path = remote_info.get('remote_path', '')
                self.remote_type = remote_info.get('remote_type', 0)
                self.remote_username = remote_info.get('remote_username', '')
                self.remote_password = remote_info.get('remote_password', '')
                self.remote_port = remote_info.get('remote_port', '')
                
                # Log connection details for debugging
                xbmc.log(f"Connecting to remote location: type={self.remote_type}, path={self.remote_path}", xbmc.LOGINFO)
                
                if not self.connect_remote():
                    return False, "Failed to connect to remote location"
                
                try:
                    # Download the backup file
                    remote_file = remote_info.get('remote_file', '')
                    if not remote_file:
                        return False, "Invalid remote file information: missing remote_file"
                        
                    local_backup = os.path.join(self.temp_dir, remote_file)
                    xbmc.log(f"Downloading {remote_file} to {local_backup}", xbmc.LOGINFO)
                    
                    if not self.download_file(remote_file, local_backup):
                        return False, "Failed to download backup file"
                    
                    backup_file = local_backup
                finally:
                    self.disconnect_remote()
            
            # For remote backups, the backup_file is now downloaded to the temp directory
            if not os.path.exists(backup_file):
                return False, f"Backup file not found: {backup_file}"
            
            # Get backup size for display
            backup_size = os.path.getsize(backup_file)
            backup_size_formatted = self.format_size(backup_size)

            # Create and initialize restore progress dialog
            self.notify(self.addon.getLocalizedString(32083), f"Size: {backup_size_formatted}", progress=True)
            self.update_progress(0, self.addon.getLocalizedString(32083), f"Size: {backup_size_formatted}")
            
            with zipfile.ZipFile(backup_file, 'r') as zipf:
                # Read manifest
                try:
                    manifest = json.loads(zipf.read('manifest.json'))
                except Exception as e:
                    return False, f"Invalid backup file (no manifest): {str(e)}"
                
                # Get list of files to restore (excluding manifest.json)
                files_to_restore = [f for f in zipf.filelist if f.filename != 'manifest.json']
                total_files = len(files_to_restore)
                current_file = 0
                
                skipped_files = []
                restored_files = 0
                restored_size = 0
                restore_section_stats = {}

                # Restore each file
                for file_info in files_to_restore:
                    current_file += 1
                    # Ensure progress never exceeds 100%
                    progress = min(int((current_file / total_files) * 100), 100)
                    
                    try:
                        normalized_name = file_info.filename.replace('\\\\', '/')

                        # Skip VCS metadata paths to avoid permission issues on restored addons.
                        if '/.git/' in normalized_name or normalized_name.startswith('.git/'):
                            skipped_files.append(file_info.filename)
                            continue

                        # Show progress with file info and size
                        file_size = file_info.file_size
                        file_size_formatted = self.format_size(file_size)
                        progress_info = f"{file_info.filename} ({file_size_formatted})"

                        # Keep progress dialog percent in sync with restore progress
                        self.update_progress(progress, self.addon.getLocalizedString(32083), progress_info)
                        
                        # Get the full path where this file should be restored
                        if file_info.filename.startswith('userdata/'):
                            # Handle userdata paths correctly
                            extract_path = os.path.join(self.kodi_userdata, os.path.relpath(file_info.filename, 'userdata'))
                        elif file_info.filename.startswith('addons/'):
                            # Handle addons paths correctly
                            extract_path = os.path.join(self.kodi_home, file_info.filename)
                        elif file_info.filename.startswith('flash/'):
                            # Handle flash paths correctly
                            extract_path = os.path.join('/', file_info.filename)
                        elif file_info.filename.startswith('repo/'):
                            # Handle repository paths correctly (repositories are in addons directory)
                            extract_path = os.path.join(self.kodi_home, 'addons', os.path.relpath(file_info.filename, 'repo'))
                        else:
                            # Handle all other files (assume they're relative to root)
                            extract_path = os.path.join('/', file_info.filename)
                        
                        # Restore the file with special handling for config.txt
                        success, error = self.restore_file(zipf, file_info, extract_path)
                        if not success:
                            raise Exception(f"Failed to restore {file_info.filename}: {error}")

                        restored_files += 1
                        restored_size += file_size
                        section_key = file_info.filename.split('/')[0] if '/' in file_info.filename else 'root'
                        section_bucket = restore_section_stats.setdefault(section_key, {'files': 0, 'bytes': 0})
                        section_bucket['files'] += 1
                        section_bucket['bytes'] += file_size
                            
                    except Exception as e:
                        error_text = str(e)
                        error_lower = error_text.lower()

                        # Continue restore on non-critical per-file issues.
                        if 'permission denied' in error_lower or 'errno 13' in error_lower or 'file name too long' in error_lower or 'errno 36' in error_lower:
                            skipped_files.append(file_info.filename)
                            xbmc.log(f"Skipping file during restore due to non-critical error: {file_info.filename} ({error_text})", xbmc.LOGWARNING)
                            continue

                        xbmc.log(f"Error restoring {file_info.filename}: {error_text}", xbmc.LOGERROR)
                        return False, error_text
            
            self.update_progress(100, self.addon.getLocalizedString(32084), f"Size: {backup_size_formatted}")

            restore_message = "Backup restored successfully"
            if skipped_files:
                restore_message = f"Backup restored with warnings (skipped {len(skipped_files)} files)"

            self.set_operation_summary('restore', True, {
                'backup_file': os.path.basename(backup_file),
                'total_files': total_files,
                'restored_files': restored_files,
                'skipped_files': len(skipped_files),
                'total_size_formatted': backup_size_formatted,
                'compressed_size_formatted': self.format_size(restored_size),
                'sections': restore_section_stats,
                'skipped_examples': skipped_files[:10],
                'message': restore_message,
            })

            if skipped_files:
                return True, restore_message
            return True, restore_message
            
        except Exception as e:
            error_msg = f"Error restoring backup: {str(e)}"
            xbmc.log(error_msg, xbmc.LOGERROR)
            self.set_operation_summary('restore', False, {
                'backup_file': os.path.basename(backup_file) if backup_file else 'Unknown',
                'message': str(e),
            })
            return False, error_msg
        finally:
            self.close_progress()
            # Clean up temporary files after successful restore
            self.cleanup_current_session()

    def backup(self, backup_name=None):
        """Create a backup of the LibreELEC system"""
        try:
            # Get backup location
            if not self.update_backup_location():
                return False

            # Create backup name if not provided
            if not backup_name:
                backup_name = f"libreelec_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"

            # Create backup
            if self.location_type == 0:  # Local
                backup_path = os.path.join(self.backup_dir, backup_name)
                success, message = self.create_backup(backup_path)
                if not success:
                    return False
            else:  # Remote
                if not self.connect_remote():
                    return False
                try:
                    backup_path = os.path.join(self.backup_dir, backup_name)
                    success, message = self.create_backup(backup_path)
                    if not success:
                        return False
                    if not self.upload_backup(backup_path, backup_name):
                        return False
                finally:
                    self.disconnect_remote()

            # Only clean up old backups if the backup was successful
            max_backups = int(self.addon.getSetting('max_backups') or "10")
            self.cleanup_old_backups(max_backups)

            return True

        except Exception as e:
            xbmc.log(f"Error during backup: {str(e)}", xbmc.LOGERROR)
            return False

    def get_last_successful_backup(self):
        """Retrieve the most recent backup time from state file or available backups."""
        profile_dir = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        last_backup_file = os.path.join(profile_dir, 'last_backup.txt')
        try:
            if os.path.exists(last_backup_file):
                with open(last_backup_file, 'r') as f:
                    last_backup = f.read().strip()
                return last_backup if last_backup else "No backup yet"

            # Fallback: infer from existing backup files when state file is missing.
            backups = self.get_all_backups()
            if backups:
                if self.location_type == 0:
                    latest_backup = max(backups, key=lambda p: os.path.getmtime(p) if os.path.exists(p) else 0)
                    return self.format_backup_date(latest_backup)
                return self.format_backup_date(backups[0])

            return "No backup yet"
        except Exception as e:
            xbmc.log(f"{ADDON_ID}: Error reading last backup time: {str(e)}", xbmc.LOGERROR)
            return "Unknown"

    def get_next_scheduled_backup(self):
        """Retrieve the date and time of the next scheduled backup based on scheduler settings."""
        try:
            # Check if scheduler is enabled
            if not self.addon.getSettingBool('enable_scheduler'):
                return "Scheduler disabled"

            # Get current time
            now = datetime.now()
            
            # Get schedule settings
            schedule_type = int(self.addon.getSetting('schedule_type') or "0")  # 0=daily, 1=weekly, 2=monthly
            schedule_time = self.addon.getSetting('schedule_time') or "00:00"
            schedule_day = int(self.addon.getSetting('schedule_day') or "0")  # 0-6 for weekly, 1-31 for monthly
            
            # Parse schedule time
            try:
                hour, minute = map(int, schedule_time.split(':'))
            except ValueError:
                return "Invalid schedule time"

            # Calculate next backup time
            next_backup = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            
            if schedule_type == 0:  # Daily
                if next_backup <= now:
                    next_backup += timedelta(days=1)
                    
            elif schedule_type == 1:  # Weekly
                # Convert schedule_day (0-6) to actual day of week
                current_day = now.weekday()
                days_ahead = schedule_day - current_day
                if days_ahead <= 0:
                    days_ahead += 7
                next_backup += timedelta(days=days_ahead)
                
            elif schedule_type == 2:  # Monthly
                # Set to the specified day of the month
                next_backup = next_backup.replace(day=schedule_day)
                if next_backup <= now:
                    # Move to next month
                    if next_backup.month == 12:
                        next_backup = next_backup.replace(year=next_backup.year + 1, month=1)
                    else:
                        next_backup = next_backup.replace(month=next_backup.month + 1)

            return next_backup.strftime("%Y-%m-%d %H:%M:%S")
            
        except Exception as e:
            xbmc.log(f"{ADDON_ID}: Error calculating next backup time: {str(e)}", xbmc.LOGERROR)
            return "Unknown"
